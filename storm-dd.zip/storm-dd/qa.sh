mvn clean compile assembly:single
scp target/storm-dd-1.0-SNAPSHOT-jar-with-dependencies.jar behavior-nimbus-0-407447.phx01.dev.ebayc3.com:~/

ssh behavior-nimbus-0-407447.phx01.dev.ebayc3.com "storm kill UsDeals"

ssh behavior-nimbus-0-407447.phx01.dev.ebayc3.com