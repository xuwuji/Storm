Storm Trident Topology

1. Aggregate p/m level clicks per minute by rolling up itm_clicks
select cnt from  itm_clicks where grp_id in ('p1_m12', 'p1_m11') and ts =  '2015-01-19 22:02:00-0800';

2. Fetch p/m item clicks detail
select itm, cnt from  itm_clicks where grp_id in ('p1_m12', 'p1_m11') and ts =  '2015-01-19 22:02:00-0800';

3. Fetch overall item clicks * n
 select cnt from clicks where grp_id = $itm and ts =  '2015-01-19 22:02:00-0800';
