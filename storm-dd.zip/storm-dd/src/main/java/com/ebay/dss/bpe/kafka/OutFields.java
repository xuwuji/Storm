package com.ebay.dss.bpe.kafka;

/**
 * Created by bishao on 3/9/15.
 */
public class OutFields {
    public final static String TIMESTAMP = "timestamp";
    
    public final static String SITE = "t";

    public final static String ITEM = "itm";

    public final static String SOURCE = "sid";

    public final static String SOURCE_PAGE = "p";

    public final static String SOURCE_MODULE = "m";

    public final static String CLICK = "click";

    public static final String GMV = "gmv";

    public static final String QTY = "qty";

}
