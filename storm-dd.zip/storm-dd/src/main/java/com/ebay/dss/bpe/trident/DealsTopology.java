package com.ebay.dss.bpe.trident;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.generated.StormTopology;
import backtype.storm.tuple.Fields;
import com.datastax.driver.core.ConsistencyLevel;
import com.ebay.dss.bpe.BaseTopology;
import com.ebay.dss.bpe.BehaviorFields;
import com.ebay.dss.bpe.TransactionFields;
import com.ebay.dss.bpe.attribution.GmvQtyMapper;
import com.ebay.dss.bpe.attribution.GmvQtySum;
import com.ebay.dss.bpe.cassandra.IntValueMapper;
import com.ebay.dss.bpe.cassandra.PersistenceManager;
import com.ebay.dss.bpe.kafka.SpoutCreator;
import com.ebay.dss.bpe.trident.operation.*;
import com.hmsonline.trident.cql.CassandraCqlMapState;
import com.hmsonline.trident.cql.CassandraCqlMapStateFactory;
import com.hmsonline.trident.cql.CassandraCqlStateFactory;
import com.hmsonline.trident.cql.mappers.CqlRowMapper;
import storm.trident.Stream;
import storm.trident.TridentTopology;
import storm.trident.operation.builtin.FilterNull;
import storm.trident.state.StateFactory;
import storm.trident.state.StateType;

import java.util.Calendar;
import java.util.Map;

import static com.ebay.dss.bpe.trident.DealsTopology.TYPE.ALL;
import static com.ebay.dss.bpe.trident.DealsTopology.TYPE.valueOf;


public class DealsTopology extends BaseTopology {
    
    enum TYPE {
        CLICK, TRANS, IMPR, ALL
    };

    private PersistenceManager persistence;
    private Map<String, Object> cassandraConf;
    private Map<String, Object> attributionConf;
    private SpoutCreator spoutCreator;

    private static Fields COUNT = new Fields(BehaviorFields.COUNT);
    private static String TS = "ts";

    public DealsTopology(String env) {
        super(env);
        init();
    }

    public DealsTopology(String env, String config) {
        super(env, config);
        init();
    }
    
    private void init() {
        cassandraConf = (Map<String, Object>)getConfig("persistence.cassandra");

        persistence = new PersistenceManager(cassandraConf);

        attributionConf = (Map<String, Object>)getConfig("app.attribution");

        spoutCreator = new SpoutCreator(getConfigString("kafka.zookeeper"), getConfigString("kafka.zkroot"));
    }
    
    
    private StateFactory createState(CqlRowMapper mapper) {
        CassandraCqlMapState.Options options = new CassandraCqlMapState.Options();
        options.keyspace = getConfigString("cassandra.keyspace");
        return new CassandraCqlMapStateFactory(
                mapper,
                StateType.NON_TRANSACTIONAL,
                options, ConsistencyLevel.ONE);
    }
    
    private void transactionStream(TridentTopology topology) {
        Stream stream = topology.newStream(getConfigString("storm.spout.transactional"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.transactional"), getConfigString("storm.kafka.client.transactional")));

        String[] names = {TransactionFields.SITE, TransactionFields.TIMESTAMP, TransactionFields.ITEM, TransactionFields.GMV, TransactionFields.USER, TransactionFields.QUANTITY};
        Fields fields = new Fields(names);
        Stream parsedStream = stream.name("t")
                .each(new Fields("str"), new TransEventParser(names), fields)
                .each(new Fields(TransactionFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")))
                .each(new Fields(TransactionFields.TIMESTAMP), new RoundTimestamp(Calendar.MINUTE), new Fields(TS));

        //so far, we get all deals items purchase events
        Fields sum = new Fields(TransactionFields.SUM);
        Fields gmvQty = new Fields(TransactionFields.GMV, TransactionFields.QUANTITY);
        
        // step 1.
        StateFactory gmvQtyState = persistence.getState(new String[]{"gmv", "qty"}, false, GmvQtyMapper.class);
        StateFactory gmvQtyStateDtl = persistence.getState(new String[]{"gmv", "qty"}, true, GmvQtyMapper.class);


        parsedStream.name("s1")//group by item+site, ts
                .groupBy(new Fields(TransactionFields.ITEM, TransactionFields.SITE, TS))
                .persistentAggregate(gmvQtyState, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        Stream attributed = parsedStream.name("a")
                .each(new Fields(TransactionFields.ITEM, TransactionFields.USER, TransactionFields.TIMESTAMP),
                        new Attribution(attributionConf, cassandraConf), new Fields(BehaviorFields.SOURCE))
                .each(new Fields(BehaviorFields.SOURCE), new SidParser(), new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE));

        // step2.2 group by p, ts, count()  -- page summary
       attributed.name("s2")
                .groupBy(new Fields(BehaviorFields.SOURCE_PAGE, TransactionFields.SITE, TS))
                .persistentAggregate(gmvQtyState, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
        
        // step2.3 group by sid, ts, gmv+qty  -- module+site summary
        attributed.name("s3")
                .groupBy(new Fields(BehaviorFields.SOURCE, TransactionFields.SITE, TS))
                .persistentAggregate(gmvQtyState, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        // step2.4 group by p+site ts, itm, gmv+qty  -- page+site, item detail ()
        attributed.name("d1")
                .groupBy(new Fields(BehaviorFields.SOURCE_PAGE, TransactionFields.SITE, TS, TransactionFields.ITEM))
                .persistentAggregate(gmvQtyStateDtl, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
      
        // step2.5 group by sid+site, ts, itm, count()  -- module, item detail ()
        attributed.name("d2")
                .groupBy(new Fields(BehaviorFields.SOURCE, TransactionFields.SITE, TS, TransactionFields.ITEM))
                .persistentAggregate(gmvQtyStateDtl, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));


        // step2.6 group by itm+site, ts, sid, count()  -- item, module detail ()
        attributed.name("d3")
                .groupBy(new Fields(TransactionFields.ITEM, TransactionFields.SITE, TS, BehaviorFields.SOURCE))
                .persistentAggregate(gmvQtyStateDtl, gmvQty, new GmvQtySum(), sum)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
    
    }

    private void clickStream(TridentTopology topology) {
        Stream stream = topology.newStream(getConfigString("storm.spout.behavioral"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.behavioral"), getConfigString("storm.kafka.client.behavioral")));

        String[] names = {BehaviorFields.TIMESTAMP, BehaviorFields.SITE, BehaviorFields.PAGE, BehaviorFields.SOURCE, BehaviorFields.ITEM, BehaviorFields.GUID, BehaviorFields.USER, BehaviorFields.BEST_USER};
        Fields fields = new Fields(names);
        Stream parsedStream = stream.name("f1")
                .parallelismHint(getConfigInt("topology.parallelismHint.parseAndFilter"))
                .each(new Fields("str"), new JsonParser(names), fields)
                .each(new Fields(BehaviorFields.PAGE, BehaviorFields.SITE), new FilterNull());
                
        viBranch(parsedStream);
        
        pvBranch(parsedStream);
    }
    
    private void viBranch(Stream head) {
        Stream vi = head.name("v")
                .each(new Fields(BehaviorFields.PAGE), new In(getConfigString("app.filters.vi").split(",")))//vi page
                .each(new Fields(BehaviorFields.ITEM), new FilterNull())//don't filter out sid is empty
                .each(new Fields(BehaviorFields.ITEM), new ItemFilter((Map<String, Object>) getConfig("app.cache")))
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.MINUTE), new Fields(TS));

        //so far, we get all deals items vi events

        StateFactory clickSumState = persistence.getState(new String[]{"click"}, false, IntValueMapper.class);
        StateFactory clickDtlState = persistence.getState(new String[]{"click"}, true, IntValueMapper.class);

        // step 1. group by itm+site, ts, count()   -- item+site summary
        vi.name("s1")
                .groupBy(new Fields(BehaviorFields.ITEM, BehaviorFields.SITE, TS))
                .persistentAggregate(clickSumState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp") * 2);//heavier than others


        String[] dealsPageIds = getConfigString("app.filters.deal").split(",");
        String[] sourcePageIds = new String[dealsPageIds.length];
        for (int i = 0; i < dealsPageIds.length; i++) {
            sourcePageIds[i] = "p" + dealsPageIds[i];
        }

        // step2. filter deals pages
        Stream dealsVIStream = vi.name("f2")
                .each(new Fields(BehaviorFields.SOURCE), new FilterNull())
                .each(new Fields(BehaviorFields.SOURCE), new SidParser(), new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SOURCE_MODULE))
                .each(new Fields(BehaviorFields.SOURCE_PAGE), new In(sourcePageIds));

        // step2.1
        //a. VI with uid: uid,itm,ts,sid, b. VI w/o uid: guid,ts,itm,sid
        dealsVIStream.name("i")
                .each(new Fields(BehaviorFields.TIMESTAMP, BehaviorFields.ITEM, BehaviorFields.USER, BehaviorFields.BEST_USER, BehaviorFields.GUID, BehaviorFields.SOURCE),
                        new Contribution(attributionConf, cassandraConf));

        // step2.2 group by p+site, ts, count()  -- page+site summary
        dealsVIStream.name("s2")
                .groupBy(new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SITE, TS))
                .persistentAggregate(clickSumState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
//
//        // step2.3 group by sid+site, ts, count()  -- source+site summary
        dealsVIStream.name("s3")
                .groupBy(new Fields(BehaviorFields.SOURCE, BehaviorFields.SITE, TS))
                .persistentAggregate(clickSumState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        // step2.4 group by p+site, ts, itm, count()  -- page+site, item detail ()
        dealsVIStream.name("d1")
                .groupBy(new Fields(BehaviorFields.SOURCE_PAGE, BehaviorFields.SITE, TS, BehaviorFields.ITEM))
                .persistentAggregate(clickDtlState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        // step2.5 group by sid + site, ts, itm, count()  -- module, item detail ()
        dealsVIStream.name("d2")
                .groupBy(new Fields(BehaviorFields.SOURCE, BehaviorFields.SITE, TS, BehaviorFields.ITEM))
                .persistentAggregate(clickDtlState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));

        // step2.6 group by itm + site, ts, sid, count()  -- item, module  detail ()
        dealsVIStream.name("d3")
                .groupBy(new Fields(BehaviorFields.ITEM, BehaviorFields.SITE, TS, BehaviorFields.SOURCE))
                .persistentAggregate(clickDtlState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
        
    }
    
    private void pvBranch(Stream head) {
        Stream deal = head.name("d").each(new Fields(BehaviorFields.PAGE), new In(getConfigString("app.filters.deal").split(",")));//deal pages

        StateFactory pvSumState = persistence.getState(new String[]{"pv"}, false, IntValueMapper.class);
        deal.name("p")
                .each(new Fields(BehaviorFields.TIMESTAMP), new RoundTimestamp(Calendar.MINUTE), new Fields(TS))
                .each(new Fields(BehaviorFields.PAGE), new Prefix("p"), new Fields("page"))
                .groupBy(new Fields("page", BehaviorFields.SITE, TS))
                .persistentAggregate(pvSumState, new Count(), COUNT)
                .parallelismHint((Integer) getConfig("topology.parallelismHint.grp"));
        
        //TODO: report itm tracking missing...
//        deal.name("mi")
//                .each(new Fields(BehaviorFields.MI), new FilterNull());
                
//                .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new FilterNull())
//                .each(new Fields(BehaviorFields.PGI, BehaviorFields.MI), new UrlDecoder(), new Fields("decoded_pgi", "decoded_mi"))
//                .project(new Fields(BehaviorFields.USER_COUNTRY, BehaviorFields.TIMESTAMP, BehaviorFields.SITE, "ts", "decoded_pgi", "decoded_mi"))
//                .each(new Fields("decoded_pgi"), new PgiParser(), new Fields("eg_id", "eid"))
//                .each(new Fields("eid"), new FilterNull());
        
        
    }

    public StormTopology build() {
        return this.build(ALL);
    }

    StormTopology build(TYPE type) {
        TridentTopology topology = new TridentTopology();
        switch (type) {
            case CLICK:
                clickStream(topology);
                break;
            case TRANS:
                transactionStream(topology);
                break;
//            case IMPR:
//                imprStream(topology);
//                break;
            default:
                clickStream(topology);
                transactionStream(topology);
//                imprStream(topology);
        }
        return topology.build();
    }

    public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
        String env = "dev";
        
        if (args != null && args.length >= 2) {
            env = args[0];
        }
        Config conf = new Config();
        if ("dev".equals(env)) {
            LocalCluster cluster = new LocalCluster();
            DealsTopology topology = new DealsTopology("dev");
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
            cluster.submitTopology(topology.getName(), conf, topology.build());
        } else {
            if (args.length != 4) {
                System.err.println("Usage: <env> <num_of_workers> <click|trans> <config file>");
                return;
            }
            DealsTopology topology = new DealsTopology(env, args[3]);
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_CQL_HOSTS, topology.getConfigString("cassandra.hosts"));
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_USERNAME, topology.getConfigString("cassandra.username"));
            conf.put(CassandraCqlStateFactory.TRIDENT_CASSANDRA_PASSWORD, topology.getConfigString("cassandra.password"));
            conf.setNumWorkers(Integer.valueOf(args[1]));


            StormSubmitter.submitTopology(topology.getName() + args[2], conf, topology.build(valueOf(args[2].toUpperCase())));
        }

    }


}
