BASE_HOME=/Applications
ZK_HOME=$BASE_HOME/apache/zookeeper-3.4.6
CASSANDRA_HOME=$BASE_HOME/apache/apache-cassandra-2.0.10
KAFKA_HOME=$BASE_HOME/apache/kafka_2.10-0.8.1.1


$ZK_HOME/bin/zkServer.sh start

$CASSANDRA_HOME/bin/cassandra

$KAFKA_HOME/bin/kafka-server-start.sh $KAFKA_HOME/config/server.properties &



$BASE_HOME//mongodb-osx-x86_64-3.0.1/bin/mongod &




