import json
import requests

from pymongo import MongoClient
from datetime import datetime
import sys


env = sys.argv[1]
print env

if env == 'prod':
  mongohost = "slcdbx1053-6.slc.ebay.com:27017,lvsdbx1003-6.lvs.ebay.com:27017,phxdbx1047-6.phx.ebay.com:27017/?replicaSet=CuratedTrendRS"
  url = 'http://www.rps.stratus.ebay.com/rps/finditems'
elif env == 'qa':
  mongohost = "sm-curatedtrend1.db.stratus.qa.ebay.com:27017,sm-curatedtrend2.db.stratus.qa.ebay.com:27017,sm-curatedtrend3.db.stratus.qa.ebay.com:27017"
  url = 'http://www.qa.ebay.com/rps/finditems'
else:
  mongohost = "localhost:27017"
  url = 'http://www.rps.stratus.ebay.com/rps/finditems'

print mongohost
print url

data = {"siteId":0,"type": "DEALS", "paginationInput":{ "entriesPerPage":200, "pageNumber":1}}
data_json = json.dumps(data)
headers = {'Content-type': 'application/json'}
response = requests.post(url, data=data_json, headers=headers)
size = response.json()['matchCount']
items = response.json()['searchRecord']
client = MongoClient("mongodb://" + mongohost)
#client = MongoClient('localhost',27017)

db = client['deals']
collection = db['items']

print size

n = size/200 + (0 if size % 200 == 0 else 1) #pages

for item in items:
  itm = item['item']
  itm['_id'] = itm.pop('itemId')
  itm['fetch_time'] = datetime.now()
  collection.save(itm)

if n > 1:
  for i in range(2, n+1):
    data = {"siteId":0,"type": "DEALS", "paginationInput":{ "entriesPerPage":200, "pageNumber":i}}
    data_json = json.dumps(data)
    response = requests.post(url, data=data_json, headers=headers)
    items = response.json()['searchRecord']
    for item in items:
      itm = item['item']
      itm['_id'] = itm.pop('itemId')
      itm['fetch_time'] = datetime.now()
      collection.save(itm)
    