1. Support both Transaction stream & Behavior stream
2. Filtering , counting


Behavior stream - 
 branch 1: p=2051542 
          pgi -> event impression
          mi -> itm impression
 branch 2: p in vips
         click attribution
         rpp_cid=550b685ee4b0f9266b7e5ffa
         rpp_icid=550b679ce4b03bec964321df
         sid=p2051542.m2753
         
         
backtype.storm.topology.ReportedFailedException: com.datastax.driver.core.exceptions.InvalidQueryException: Invalid null clustering key part grp2 at com.hmsonline.trident.cql.CassandraCqlMapState.che