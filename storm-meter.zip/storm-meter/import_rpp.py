import time
import requests
import json

from pymongo import MongoClient
from datetime import datetime

url = 'http://www.rps.stratus.ebay.com/rps'
#http://www.qa.ebay.com/rps
#mongohost = 'chd1b02c-27a5.stratus.phx.ebay.com'
mongohost = 'localhost'

start = int(round(time.time() * 1000))
end = start + 86400000

events_url = url + '/events?&active=true&startsBefore='+ str(start) +'&endsAfter='+ str(end)
print events_url
events_response = requests.get(events_url)

print 'total active events: ' + str(events_response.json()['totalCount'])
events = events_response.json()['events']

item_url = url + '/finditems'
client = MongoClient(mongohost,27017)
db = client['rpp']
collection = db['items']

item_count = 0
headers = {'Content-type': 'application/json'}
for event in events:
    data = {"siteId": event['siteId'], "eventId": event['id'], "paginationInput":{ "entriesPerPage":1000000, "pageNumber":1}}
    data_json = json.dumps(data)
    # print data_json
    response = requests.post(item_url, data=data_json, headers=headers)
    # print response.json()
    result = response.json()

    n = int(result['matchCount'])
    item_count = item_count + n
    if n > 0:
        items = result['searchRecord']
        for item in items:
            itm = item['item']
            itm['_id'] = itm.pop('itemId')
            itm['fetch_time'] = datetime.now()
            collection.save(itm)
print 'total items imported from active events:' + str(item_count)