package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 4/21/15.
 * 
 * pgi=2051542:0|3205:5515996fe4b02f4e9b82ee7f|1670:552ea18fe4b0e7076a644388
 * * *
 *  3205 event_group_id 1670 event_id
 */
public class PgiParser extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(PgiParser.class);
    
    @Override
    public void execute(TridentTuple tridentTuple, TridentCollector tridentCollector) {
        String pgi = (String)tridentTuple.get(0);
        Values values = new Values();
        try {
            String[] ids = parse(pgi);
            values.add(ids[0]);
            values.add(ids[1]);
            tridentCollector.emit(values);
        } catch (Exception e) {
            log.error("Unable to parse pgi:" + pgi);
        }
        
    }
    
    //0: event_group_id; 1: event_id 
    String[] parse(String pgi) {
        String[] rtn = new String[2];
        int g = pgi.indexOf("3205:");
        int e = pgi.indexOf("1670:");
        if( g >= 0) {
            rtn[0] = pgi.substring(g + 5, g + 29);
        }
        if (e >= 0) {
            rtn[1] = pgi.substring(e + 5, e + 29);
        }
        return rtn;
        
    }
}
