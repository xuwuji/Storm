package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 3/9/15.
 */
public class One extends BaseFunction {
    private static final Values ONE = new Values(1);
    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        collector.emit(ONE);
    }
}
