package com.ebay.dss.bpe.cassandra;

public interface Aggregatable<T> {
    T add(T var1);
}
