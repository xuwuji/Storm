package com.ebay.dss.bpe.trident.operation;

import com.ebay.dss.bpe.attribution.AttributionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFilter;
import storm.trident.operation.TridentOperationContext;
import storm.trident.tuple.TridentTuple;

import java.util.Map;

/**
 * Created by bishao on 2/19/15.
 */
public class Contribution extends BaseFilter {
    private static final Logger log = LoggerFactory.getLogger(Contribution.class);

    private transient AttributionManager attManager;
    private Map<String, Object> conf;
    private Map<String, Object> cassandraConf;
    
    public Contribution(Map<String, Object> conf, Map<String, Object> cassandraConf) {
        this.conf = conf;
        this.cassandraConf = cassandraConf;
    }
    
    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        attManager = new AttributionManager(this.conf, cassandraConf);
    }


    @Override
    public boolean isKeep(TridentTuple tuple) {
        Long timestmp = (Long)tuple.get(0);
        String itemId = (String)tuple.get(1);
        
        String uid = (String)tuple.get(2);
        String bUid = (String)tuple.get(3);
        String guid = (String)tuple.get(4);

        String source = (String)tuple.get(5);
        
        String[] keys = new String[2];
        keys[0] = itemId;
        if (uid != null) {
            keys[1] = uid;
        } else if (bUid != null) {
            keys[1] = bUid;
        } else {
            keys[1] = guid;
        }
        attManager.contribute(timestmp, keys, source);
        return false;
    }
}