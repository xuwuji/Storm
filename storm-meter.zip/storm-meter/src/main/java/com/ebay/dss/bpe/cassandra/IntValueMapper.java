package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;

/**
 * Created by bishao on 11/7/15.
 */
public class IntValueMapper extends CompoundKeyRowMapper<Integer> {
    /**
     *
     * @param keyspace
     * @param table
     */
    public IntValueMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }
    @Override
    public Integer getValue(Row row) {
        return row.getInt(columns[columns.length -1]);
    }

}
