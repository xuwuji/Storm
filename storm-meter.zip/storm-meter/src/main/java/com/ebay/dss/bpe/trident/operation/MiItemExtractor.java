package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by bishao on 4/20/15.
 */
@Deprecated
public class MiItemExtractor extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(MiItemExtractor.class);
    //mi=2154|1133:228NNKNO,26RJZ6QL,26VDQG72,2262AXGS,1XKJ7ZD1,26S92WRD,1XKJ7ZCE,26VDQFXF,1XK034Y2,26S92WM8,2262AXHY,26VDQFXB,26RJZ6OU,26S92WHJ,1XK03509,2262AXH5,1XK034XT,2262AXGR,1XKYTM3I,225NRDFY,1XN2U5D3,26TF692J,1XN2U59F,226VOF0V,26S92WQB,26VDQG5S,225KLXH6,225KLXIU,26RJZ6MK,26RJZ6NM,225KLXFH,2262AXGF,1XKJ7ZEB,26RJZ6NJ,1XKJ7ZHI,228NNKLG,2262AXG3,225KLXK1,1XKJ7ZFO,26S92WFQ,1XKJ7ZCV,228NNKKG,26VDQG0X,26VDQG24,225KLXFM,228NNKM9,225KLXJA,2262AXGZ,26S92WP1,228NNKKM,26S92WPN,26VDQG7K,1XKJ7ZE9,226RPUM6,1XNIT1EZ,1XK0350U,26RJZ6U0,226RPUS5,26T440CO,26RJZ6PH,26RJZ6NT,,2163,2159,2160,2162,2158,2155,2164,2161,2753

    @Override
    public void execute(TridentTuple tridentTuple, TridentCollector tridentCollector) {
        String mi = (String)tridentTuple.get(0);
        try {
            List<Long> list = parse(mi);
            for (Long id: list) {
                tridentCollector.emit(new Values(id.toString()));
            }
        } catch (Exception e) {
            log.error("Unable to parse mi:" + mi);
        }
        
    }
    
    List<Long> parse(String mi) {
        List<Long> ids = new ArrayList<Long>(40);
        int i = mi.indexOf("1133:");
        if (i >= 0) {
            String str = mi.substring(i + 5);
            StringTokenizer st = new StringTokenizer(str, ",");
            while(st.hasMoreElements()) {
                String encoded = st.nextToken();
                if (encoded.length() > 6) {
                    try {
                        Long id = Long.valueOf(encoded, 36);
                        ids.add(id);
                    } catch (NumberFormatException ne) {//breaking token
                        break;
                    }
                } else {//breaking token
                    break;
                }
            }
        }
        return ids;

    }
    
    
    
}
