package com.ebay.dss.bpe.trident.operation;

import storm.trident.operation.BaseFilter;
import storm.trident.tuple.TridentTuple;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by bishao on 6/26/15.
 */
public class DistinctValues extends BaseFilter {
    private Map<String, Integer> map = new HashMap<String, Integer>();
    
    private int i = 0;

    @Override
    public boolean isKeep(TridentTuple tuple) {
        String value = (String) tuple.get(0);
        Integer count = map.get(value);
        if (count != null) {
            map.put(value, count + 1);
        } else {
            map.put(value, 1);
        }
//        if (i % 10000 == 0) {
            System.out.println("DistinctValues of " + tuple.getFields() + " : " + map);
//        }
        i++;
        return true;
    }
}

