package com.ebay.dss.bpe.bolt;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

/**
 * Created by bishao on 7/17/15.
 */
public abstract class HeadBolt extends BaseRichBolt {
    private static final Logger log = LoggerFactory.getLogger(HeadBolt.class);
    
    protected OutputCollector collector;
    private ObjectMapper mapper;
    private String[] outputFields;

    public HeadBolt(String... outputFields) {
        this.outputFields = outputFields;
    }

    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        this.mapper = new ObjectMapper();
    }

    @Override
    public void execute(Tuple input) {
        try {
            String str = new String(input.getString(0));
//            System.out.println(str);
            Map<String, Object> fields = mapper.readValue(str, Map.class);
            process(input, fields);
        } catch (IOException e) {
            log.error("Unable to parse json from value {}", input);
        }
        collector.ack(input);
    }

    //process the fields, e.g. filtering, and then emit new values
    abstract protected void process(Tuple anchor, Map<String, Object> fields);

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields(this.outputFields));
    }
}
