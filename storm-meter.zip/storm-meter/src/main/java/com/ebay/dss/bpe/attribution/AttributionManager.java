package com.ebay.dss.bpe.attribution;

import com.datastax.driver.core.*;
import com.ebay.dss.bpe.cassandra.PersistenceManager;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

/**
 * Created by bishao on 4/27/15.
 */
public class AttributionManager implements Serializable {
    private static final Logger log = LoggerFactory.getLogger(AttributionManager.class);
    
    private PersistenceManager persistenceManager;
    private long attributeWin;
    private transient PreparedStatement insert, select;


    public AttributionManager(Map<String, Object> config, Map<String, Object> cassandraConf) {
        persistenceManager = new PersistenceManager(cassandraConf);

        String cqlInStmt = "INSERT INTO " + persistenceManager.getFactTable() + " (id, ts, ref) VALUES (?, ?, ?)";
        insert = persistenceManager.getSession().prepare(cqlInStmt);
        
        String cqlSelStmt = "SELECT ref FROM " + persistenceManager.getFactTable() + " WHERE id = ? and ts >= ? and ts < ? LIMIT 1";
        select = persistenceManager.getSession().prepare(cqlSelStmt);
        attributeWin = Long.valueOf((Integer) config.get("attribute.window"));
    }
    
    //attribute back
    public String attribute(Long timestamp, String... keys) {
        BoundStatement bind = select.bind(StringUtils.join(keys, "_"), new Date(timestamp - attributeWin), new Date(timestamp));
        try {
            ResultSet results = persistenceManager.getSession().execute(bind);
            Row row = results.one();
            if (row != null) {
                return row.getString(0);
            } else {
                log.debug("Not attributed...timestamp={}, keys={}", timestamp, Arrays.toString(keys));
            }
        } catch (Exception e) {
            log.error("Unable to attribute by using ts={} value={}", timestamp, Arrays.toString(keys));
        }
        return null;
    }
    
    //contribute for later attribution
    public void contribute(Long timestamp, String[] keys, String value) {
        try{
            Statement in = insert.bind(StringUtils.join(keys, "_"), new Date(timestamp), value);
            persistenceManager.getSession().executeAsync(in);
        } catch (Exception e) {
            log.error("Unable to contribute by using ts={} key={} value={} due to {}", timestamp, Arrays.toString(keys), value, e);
        }
        
        
    }
}
