package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.*;

/**
 * Created by bishao on 4/21/15.
 */
public class TrkpParser extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(TrkpParser.class);

    private String[] keys;
    public TrkpParser(String... keys) {
        this.keys = keys;
    }
    
    @Override
    public void execute(TridentTuple tridentTuple, TridentCollector tridentCollector) {
        String trkp = (String)tridentTuple.get(0);
        try {
            Map<String, String> extracted = extract(trkp);
            
            Values values = new Values();
            for (String key : keys) {
                values.add(extracted.get(key));
            }
            tridentCollector.emit(values);
        } catch (Exception e) {
            log.error("Unable to parse trkp: {}", trkp, e);
        }
    }
    
    Map<String, String> extract(String trkp) {
        Map<String, String> rtn = new HashMap<String, String>(keys.length);
        //&rpp_cid=550b685ee4b0f9266b7e5ffa&rpp_icid=550b679ce4b03bec964321df
        StringTokenizer st = new StringTokenizer(trkp, "&");
        while(st.hasMoreElements()) {
            String kv = st.nextToken();
            int i = kv.indexOf("=");
            if (i > 0) {
                rtn.put(kv.substring(0, i), kv.substring(i + 1));
            }
        }
        return  rtn;
    }
    
}
