package com.ebay.dss.bpe.cassandra;

import java.util.List;

/**
 * Created by bishao on 11/7/15.
 */
public abstract class CompoundKey<T> {
    protected List<Object> keys;
    
    public CompoundKey(List<Object> keys) {
        this.keys = keys;
    }
    
    public abstract T get();
}
