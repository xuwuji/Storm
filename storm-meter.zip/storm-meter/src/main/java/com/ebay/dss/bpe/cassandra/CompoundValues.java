//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.ebay.dss.bpe.cassandra;

import java.util.List;

public abstract class CompoundValues<T extends CompoundValues> implements Aggregatable<T> {
    protected List<Object> values;

    public CompoundValues(List<Object> values) {
        this.values = values;
    }

    public Object get(int i) {
        return this.values.get(i);
    }

    public int size() {
        return this.values.size();
    }
}
