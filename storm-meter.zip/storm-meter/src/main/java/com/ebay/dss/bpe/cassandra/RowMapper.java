package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Statement;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.hmsonline.trident.cql.mappers.CqlRowMapper;
import storm.trident.tuple.TridentTuple;

import java.io.Serializable;
import java.util.List;

/**
 * K,V Mapper
 * Use BaseRowMapper
 * * *
 */
@Deprecated
public abstract class RowMapper<V> implements CqlRowMapper<List<Object>, V>,Serializable {
    /**
	 *
	 */
	private static final long serialVersionUID = 7738276337117186606L;
    protected String keyspace;
    protected String table;
    protected String[] columns;
    protected Object[] columnValues;


    public RowMapper(String keyspace, String table, List<String> columns) {
        this.columnValues = new Object[columns.size()];
        this.table = table;
        this.keyspace = keyspace;
        this.columns = columns.toArray(new String[0]);
    }

    @Override
    public Statement map(List<Object> key, V value) {
        Insert statement = QueryBuilder.insertInto(keyspace, table);
        for (int i = 0; i < key.size(); i++) {
            columnValues[i] = key.get(i);
        }
        columnValues[columnValues.length - 1] =  value;
        statement.values(columns, columnValues);
//        statement.using(QueryBuilder.ttl(ttl));
        return statement;
    }

    @Override
    public Statement map(TridentTuple tridentTuple) {
        Insert statement = QueryBuilder.insertInto(keyspace, table);
        statement.values(columns, tridentTuple.toArray());
//        statement.using(QueryBuilder.ttl(ttl));
        return statement;
    }

    @Override
    public Statement retrieve(List<Object> key) {
        Select statement = QueryBuilder.select(columns)
                .from(keyspace, table);
        for (int i = 0; i < key.size(); i++) {
            statement.where(QueryBuilder.eq(columns[i], key.get(i)));
        }
        return statement;
    }
}
