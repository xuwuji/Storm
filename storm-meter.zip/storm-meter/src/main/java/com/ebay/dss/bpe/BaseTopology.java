package com.ebay.dss.bpe;

import backtype.storm.generated.StormTopology;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 * Created by bishao on 1/16/15.
 */
public abstract class BaseTopology {
    private static final Logger log = LoggerFactory.getLogger(BaseTopology.class);

    Map<String, Object> config;

    public BaseTopology(String env) {
        System.out.println("Topology running environment: " + env);
        try {
            InputStream input = this.getClass().getResourceAsStream(
                    "/" + this.getClass().getSimpleName() + ".yaml");
            Yaml yaml = new Yaml();
            Map map = (Map)yaml.load(input);
            config = (Map)map.get(env.toUpperCase());
            input.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public BaseTopology(String env, String file) {
        System.out.println("Topology running environment: " + env);
        try {
            InputStream input = new FileInputStream(file);
            Yaml yaml = new Yaml();
            Map map = (Map)yaml.load(input);
            config = (Map)map.get(env.toUpperCase());
            input.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Object getConfig(String key) {
        return config.get(key);
    }
    
    public String getConfigString(String key) {
        Object value = config.get(key);
        if (!(value instanceof String)) {
            log.warn("{} is not configured as String", key);
        }
        if(config.get(key) != null) {
            return config.get(key).toString();
        } else {
            throw new RuntimeException(key + " is not configured");
        }
    }

    public Boolean getConfigBool(String key) {
        Object value = config.get(key);
        if (!(value instanceof Boolean)) {
            log.warn("{} is not configured as Boolean", key);
        }
        return (Boolean)config.get(key);
    }
    
    public Integer getConfigInt(String key) {
        Object value = config.get(key);
        if (value instanceof Integer) {
            return (Integer)value;
        } else {
            throw new RuntimeException(key + " is not configured as Integer.");
        }
    }

    public Map<String, Object> getConfig() {
        return config;
    }

    public String getName() {
        return config.get("topology.name").toString();
    }

    public abstract StormTopology build();



}
