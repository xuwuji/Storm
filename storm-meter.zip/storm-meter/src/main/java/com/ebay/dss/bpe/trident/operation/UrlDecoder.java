package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.net.URLCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.Iterator;

/**
 * Created by bishao on 4/20/15.
 */
public class UrlDecoder extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(UrlDecoder.class);

    private static final String EMPTY = "";
    
    public UrlDecoder() {
    }
    
    @Override
    public void execute(TridentTuple tridentTuple, TridentCollector tridentCollector) {
        Iterator<Object> iterator = tridentTuple.iterator();
        Values result = new Values();
        while(iterator.hasNext()) {
            result.add(decode((String)iterator.next()));
        }
        tridentCollector.emit(result);
    }
    
    String decode(String encoded) {
        if (encoded == null || EMPTY.equals(encoded.trim())) {
            return EMPTY;
        }
        try {
            byte[] bytes = new byte[0];
            bytes = URLCodec.decodeUrl(encoded.getBytes());
            return new String(bytes);
        } catch (DecoderException e) {
            log.warn("Unable to decode {}", encoded);
            return EMPTY;
        }
        
    }
}
