package com.ebay.dss.bpe.kafka;

import org.json.simple.JSONValue;
import storm.kafka.trident.mapper.TridentTupleToKafkaMapper;
import storm.trident.tuple.TridentTuple;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by bishao on 3/9/15.
 */
public class KafkaMapper implements TridentTupleToKafkaMapper<String, String> {
    private String[] names;
    private Map<String, Object> map;

    public KafkaMapper(String... names) {
        this.names = names;
        map = new HashMap<String, Object>(names.length);
    }
    @Override
    public String getKeyFromTuple(TridentTuple tuple) {
        return null;
    }

    @Override
    public String getMessageFromTuple(TridentTuple tuple) {
        map.clear();
        for (int i = 0; i < names.length; i++) {
            map.put(names[i], tuple.get(i));

        }
        return JSONValue.toJSONString(map);
    }
}
