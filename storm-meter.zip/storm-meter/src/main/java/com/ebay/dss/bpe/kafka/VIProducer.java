package com.ebay.dss.bpe.kafka;


import kafka.producer.KeyedMessage;
import org.json.simple.JSONValue;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by bishao on 11/4/14.
 */
public class VIProducer extends BehavioralEventsProducer {

    public static void main(String[] args) throws Exception {
        VIProducer producer = new VIProducer();
        producer.produce();
    }

    @Override
    void produce() throws Exception {
        int evtCnt = 10000;
        String[] sites = {"0"
//                , "1"
        };
        String[] pages = {"2047675"
                //, "123456"
        };
        String[] sids = {
                "p2051542.m1",
//                "p1468660.m2",
//                "p2051640.m1",
//                "p2051641.m1",
//                "p2051642.m1",
//                "p2051643.m1",
//                "p2058484.m3",
//                "p2065262.m4",
//                "p2065859.m5",
//                "p12345",
//                "m0", "p1.m2"
        };
        String[] items = {"400900510680", "331028273672","281572765965", "271617233213"
//                , "123456789"
        };
        String[] users = {"123456"};

        Random random = new Random();
        Map<String, Object> event = new HashMap<String, Object>();
        for (int i = 0; i < evtCnt; i ++) {
            event.put("t", sites[random.nextInt(sites.length)]);
            event.put("p", pages[random.nextInt(pages.length)]);
            event.put("sid", sids[random.nextInt(sids.length)]);
            event.put("itm", items[random.nextInt(items.length)]);
            event.put("timestamp", System.currentTimeMillis());
            event.put("u", users[random.nextInt(users.length)]);
            event.put("trkp", "%26rpp_cid%3D55394828e4b01296ae988a8a%26rpp_icid%3D55394741e4b0d23612afd35f");

            KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, JSONValue.toJSONString(event));
            producer.send(msg);
            Thread.sleep(1000);

        }
        producer.close();
    }
}

