package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by bishao on 1/14/15.
 */
public class RoundTimestamp extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(RoundTimestamp.class);
    private int divisor;
    private int diff;

    public RoundTimestamp(int granularity) {
        switch (granularity) {
            case Calendar.SECOND:
                log.info("round to seconds");
                divisor = 1000;
                diff = 0;
                break;
            case Calendar.MINUTE:
                log.info("round to minutes");
                divisor = 60000;
                diff = 0;
                break;
            case Calendar.HOUR:
                log.info("round to hours");
                divisor = 3600000;
                diff = 0;
                break;
            case Calendar.DATE:
                log.info("round to days");
                divisor = 86400000;
                diff = 7 * 3600000; //eBay default timezone MST -07:00
                break;
            default:
                throw new IllegalArgumentException("Not accepted granularity.");
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        long timestamp = tuple.getLong(0);
        Date rounded = round(timestamp);
        Values values = new Values();
        values.add(rounded);
        collector.emit(values);
    }
    
    Date round(long timestamp) {
        return new Date((timestamp/divisor) * divisor + diff);
    }


}
