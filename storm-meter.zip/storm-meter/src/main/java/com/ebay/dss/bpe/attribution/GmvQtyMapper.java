package com.ebay.dss.bpe.attribution;

import com.datastax.driver.core.Row;
import com.ebay.dss.bpe.cassandra.CompoundKVRowMapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by bishao on 11/6/15.
 */
public class GmvQtyMapper extends CompoundKVRowMapper<GmvQty> {
    
    public GmvQtyMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }

    @Override
    public GmvQty getValue(Row row) {
        BigDecimal gmv = row.getDecimal("gmv");
        return new GmvQty(new ArrayList<Object>(Arrays.asList(gmv != null ? gmv.doubleValue() : 0, row.getInt("qty"))));
    }
}
