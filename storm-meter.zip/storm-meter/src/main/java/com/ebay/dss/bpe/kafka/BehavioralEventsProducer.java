package com.ebay.dss.bpe.kafka;

import kafka.javaapi.producer.Producer;
import kafka.producer.ProducerConfig;

import java.util.Properties;

/**
 * Created by bishao on 4/21/15.
 */
public abstract class BehavioralEventsProducer {

    static Properties props = new Properties();
    static {
        props.put("metadata.broker.list", "localhost:9092");
        props.put("zk.connect", "localhost:2181");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        props.put("request.required.acks", "1");
    }

    static String TOPIC = "behavioral.event";
    private ProducerConfig config = new ProducerConfig(props);

    protected Producer<String, String> producer = new Producer<String, String>(config);
    
    abstract void produce() throws Exception;
}
