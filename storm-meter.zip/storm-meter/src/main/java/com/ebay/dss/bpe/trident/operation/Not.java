package com.ebay.dss.bpe.trident.operation;

import storm.trident.operation.BaseFilter;
import storm.trident.operation.Filter;
import storm.trident.tuple.TridentTuple;

/**
 */
public class Not extends BaseFilter {
    private Filter delegate;
    
    public Not(Filter filter) {
        delegate = filter;
    }

    @Override
    public boolean isKeep(TridentTuple tuple) {
        return !delegate.isKeep(tuple);
    }
}
