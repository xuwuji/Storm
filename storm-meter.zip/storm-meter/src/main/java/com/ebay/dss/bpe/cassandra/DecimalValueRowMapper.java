package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;

import java.math.BigDecimal;
import java.util.List;

/**
 */
@Deprecated
public class DecimalValueRowMapper extends RowMapper<BigDecimal> {

    /**
     *
     * @param keyspace
     * @param table
     * @param columns
     */
    public DecimalValueRowMapper(String keyspace, String table, List<String> columns) {
        super(keyspace, table, columns);
    }
    @Override
    public BigDecimal getValue(Row row) {
        return row.getDecimal(columns[columns.length - 1]);
    }


}
