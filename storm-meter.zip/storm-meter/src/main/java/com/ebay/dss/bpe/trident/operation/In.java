package com.ebay.dss.bpe.trident.operation;

import storm.trident.operation.BaseFilter;
import storm.trident.tuple.TridentTuple;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by bishao on 1/13/15.
 */
public class In extends BaseFilter {

    private Set<Object> values;

    public In(Object... values) {
        this.values = new HashSet<Object>(values.length);
        for (Object v : values) {
            this.values.add(v);
        }
    }
    @Override
    public boolean isKeep(TridentTuple tuple) {
        Object value = tuple.get(0);
        return values.contains(value);
    }
}
