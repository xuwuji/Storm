package com.ebay.dss.bpe.kafka;


import kafka.producer.KeyedMessage;
import org.json.simple.JSONValue;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by bishao on 11/4/14.
 */
public class RPPEventProducer extends BehavioralEventsProducer {

    public static void main(String[] args) throws Exception {
        RPPEventProducer producer = new RPPEventProducer();
        producer.produce();
    }


    @Override
    void produce() throws Exception {
        int evtCnt = 10000;
        String[] pgi = {
                "2051542%3A0|3205%3A5515996fe4b02f4e9b82ee7f|1670%3A553111ede4b073ce02f2e462|900%3A48",
                "2051542%3A0|3205%3A5515996fe4b02f4e9b82ee7f|1670%3A553111ede4b073ce02f2e462|900%3A96"
        };
        
        String[] mi = {
                "2156,2161,2160,2163,2158,2164,2155,2154|1133%3A1ODJO7WV%2C,2162,2159",
                "2156,2161,2160,2163,2158,2164,2155,2154|1133%3A26TCQY2R%2C225KLY36%2C1XK035JK%2C225KLY1B%2C26RJZ7A3%2C4LT64070%2C229GFJA4%2C1O2FAEGU%2C222CX6LE%2C26RJZ781%2C26RJZ7LK%2C2BCQINUN%2C225VFI5A%2C26RJZ7D5%2C1XK8WE0C%2C1ODZHAR4%2C1T1SL8UH%2C1T1SL8Y3%2C1T01D5BR%2C1ODYTOMF%2C1T1SL8V7%2C4V3XWRTG%2C1ODYTOBG%2C1T16U0LL%2C1T08ORNZ%2C4V3XVLWQ%2C26SDCVEA%2C226A5GFC%2C1O657WKM%2C2255U35D%2C4LRY4YWG%2C4LUY9HGN%2C3YYTEH6L%2C4LOTWOLY%2C224IBCEM%2C4LY0XTEW%2C228TN4H8%2C4LY0XQUA%2C4LUMQT9W%2C4QHFE4EQ%2C1O658XWZ%2C227ATFEO%2C4ZMEDXHN%2C4LS70WXC%2C4LN53UT1%2C225NPOF0%2C1OAJEH22%2C4LW3FDM3%2C2FWSFDUA%2C21Y8GSWY%2C4LVX9NHI%2C1OAEOH0Y%2C1O4FB822%2C4H55SKZD%2C1O4FB824%2C1O4HGQ2W%2C21YLNDMC%2C4QI4MUQ3%2C222CNGLU%2C1O8F5WAC%2C4ZEH4692%2C1O89DNGV%2C2YBBSO46%2C4LTMI1P9%2C544O8NHZ%2C544XI3FU%2C225KLY76%2C26RKQ2NR%2C225KLY6G%2C225KLY2D%2C2KHB9IKD%2C225RA8A9%2C3UD2KYYO%2C4ZM4JYAY%2C1JTWVWAA%2C3PTLRKHB%2C1ODEQPLY%2C543M77FZ%2C1JRMAHF1%2C1SXS0EMQ%2C3PTA32OV%2C4H89WTS2%2C1SVO0R1J%2C4LSBXB2O%2C4LPLUZ6U%2C4LSDFFDE%2C3PSRAGIH%2C26RNRDN5%2C1XLFZF4I%2C2KG6U61O%2C225NPR7W%2C1XKJ7ZE4%2C1XLJT0J6%2C2KG6WT5O%2C2KGMSV7X%2C2KHBQ1V1%2C,2162,2159"
        };

        Random random = new Random();
        Map<String, Object> event = new HashMap<String, Object>();
        for (int i = 0; i < evtCnt; i ++) {
            event.put("t", "0");
            event.put("p", "2051542");
            event.put("pgi", pgi[random.nextInt(pgi.length)]);
            event.put("mi", mi[random.nextInt(mi.length)]);
            event.put("timestamp", System.currentTimeMillis());

            KeyedMessage<String, String> msg = new KeyedMessage<String, String>(TOPIC, JSONValue.toJSONString(event));
            producer.send(msg);
            Thread.sleep(10000);

        }
        producer.close();
    }
}

