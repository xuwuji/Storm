package com.ebay.dss.bpe.trident.operation;


import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * Created by bishao on 1/14/15.
 */
public class SidParser extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(SidParser.class);

    private static final String EMPTY = "";
    /*
    * parsing sid -> p123.m456
    * */
    public SidParser() {
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String sid = (String) tuple.get(0);
        Values result = new Values();
        try {
            String[] pm = parse(sid);
            result.add(pm[0]);
            result.add(pm[1]);
            collector.emit(result);
        } catch (Exception e) {
            log.error("Unable to parse sid {}", sid, e);

        }
    }

    private static String[] parse(String sid) {
        String[] pm = new String[] {EMPTY, EMPTY};
        if (sid != null && !EMPTY.equals(sid.trim())) {
            StringTokenizer st = new StringTokenizer(sid.toString(), ".");
            while (st.hasMoreElements()) {
                String token = st.nextToken();
                if (token.startsWith("p")) {
                    pm[0] = token;
                }
                if (token.startsWith("m")) {
                    pm[1] = token;
                }
            }
        }
        return pm;
    }

    public static void main(String[] args) {
        String sid = "p2045573.m1686";
        System.out.println(Arrays.toString(SidParser.parse(sid)));
    }

}