package com.ebay.dss.bpe.trident.operation;

import org.apache.commons.lang.StringUtils;
import storm.trident.operation.BaseFilter;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 4/26/15.
 */
public class Speedometer extends BaseFilter {
    
    private long i = 0;
    private int gage;
    public Speedometer() {
        gage = 10000;
    }
    
    public Speedometer(int gage) {
        this.gage = gage;
    }

    @Override
    public boolean isKeep(TridentTuple tridentTuple) {
        i++;
        if (i%gage == 0) {
            System.out.println(StringUtils.join(tridentTuple.getFields().iterator(), ",")
                    + ":" + StringUtils.join(tridentTuple.iterator(), ","));
        }
        return true;
    }
}
