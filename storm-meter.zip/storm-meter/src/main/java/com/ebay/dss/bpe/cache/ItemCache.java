package com.ebay.dss.bpe.cache;

import com.mongodb.*;
import gnu.trove.iterator.TLongIterator;
import gnu.trove.set.hash.TLongHashSet;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by bishao on 1/25/15.
 */
public class ItemCache extends Timer {
    private static final Logger log = LoggerFactory.getLogger(ItemCache.class);

    private static ItemCache instance;

    private Map<String, Object> config;
    private TLongHashSet set;


    private ItemCache(Map<String, Object> config) {
        this.config = config;
        set = new TLongHashSet((Integer)config.get("initialCapacity"),
                ((Double)config.get("loadFactor")).floatValue());
    }
    public static void init(Map<String, Object> config) {
        if(instance == null) {
            synchronized(ItemCache.class) {
                if(instance == null) {
                    log.info("Initializing Item Cache...");
                    instance = new ItemCache(config);
                    instance.refresh();
                    RefreshTask task = new RefreshTask();
                    long interval = Long.valueOf((Integer) config.get("refreshMilliseconds"));//ymal recognize as int...
                    instance.scheduleAtFixedRate(task, interval, interval);
                }
            }
        }
    }

    public static ItemCache getInstance() {
        if (instance == null) {
            throw new RuntimeException("Call ItemCache.init() first.");
        }
        return instance;
    }

    public boolean contains(long item) {
        return set.contains(item);
    }

    private void refresh() {
        Mongo mongo = null;
        try {
            log.info("Refreshing Item Cache, initial size {}", set.size());
            List<String> hosts = (List<String>)config.get("mongoHosts");
            List<ServerAddress> servers = new ArrayList<ServerAddress>(hosts.size());
            for (int i = 0; i < hosts.size(); i++) {
                String[] hostStr = hosts.get(i).split(":");
                servers.add(new ServerAddress(hostStr[0], Integer.valueOf(hostStr[1])));
            }
            mongo = new MongoClient(servers);

            DBCollection collection = mongo.getDB((String)config.get("mongoDB")).
                    getCollection((String) config.get("mongoCollection"));
            BasicDBObject keys = new BasicDBObject();
            keys.put("_id", 1);
            Date date = DateUtils.addHours(new Date(), -1 * (Integer)config.get("livehour"));
            BasicDBObject query = new BasicDBObject("fetch_time", new BasicDBObject("$gte", date));
            log.info("Refreshing Item Cache with: " + query.toString());
            DBCursor cursor = collection.find(query, keys);
            TLongHashSet newSet = new TLongHashSet((Integer)config.get("initialCapacity"),
                    ((Double)config.get("loadFactor")).floatValue());
            while (cursor.hasNext()) {
                DBObject object = cursor.next();
                Long id = (Long) object.get("_id");
                newSet.add(id);
                set.add(id);
            }
            if (newSet.size() > 0) {
                TLongIterator iterator = set.iterator();
                while (iterator.hasNext()) {
                    long t = iterator.next();
                    if (!newSet.contains(t)) {
                        iterator.remove();
                    }
                }
            }
            log.info("After refresh, item Cache size {}", set.size());
        } catch (Exception e) {
            log.error("Unable to get items from MongoDB:", e);
        } finally {
            if (mongo != null) {
                mongo.close();
            }
        }

    }

    private static class RefreshTask extends TimerTask {
        @Override
        public void run() {
            ItemCache.getInstance().refresh();
        }
    }

    public static void main(String[] args) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put("mongoHosts", Arrays.asList("localhost:27017"));
        config.put("mongoDB", "deals");
        config.put("mongoCollection", "items");
        config.put("refreshMilliseconds", 60000);
        config.put("initialCapacity", 10000);
        config.put("loadFactor", 1.0);
        config.put("livehour", 48);
        ItemCache.init(config);
        ItemCache.getInstance();
    }

}
