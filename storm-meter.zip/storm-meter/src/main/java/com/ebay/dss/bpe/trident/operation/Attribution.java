package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import com.ebay.dss.bpe.attribution.AttributionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.operation.TridentOperationContext;
import storm.trident.tuple.TridentTuple;

import java.util.Map;

/**
 * Created by bishao on 2/22/15.
 */
public class Attribution extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(Attribution.class);

    private transient AttributionManager attManager;
    private Map<String, Object> conf;
    private Map<String, Object> cassandraConf;

    public Attribution(Map<String, Object> conf, Map<String, Object> cassandraConf) {
        this.conf = conf;
        this.cassandraConf = cassandraConf;
    }
    
    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        attManager = new AttributionManager(this.conf, cassandraConf);
    }
    
    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String item = (String) tuple.get(0);
        String user = (String) tuple.get(1);
        Long timestamp = (Long) tuple.get(2);
        String attributed = attManager.attribute(timestamp, item, user);
        if (attributed != null) {
            collector.emit(new Values(attributed));
        }
    }
}
