package com.ebay.dss.bpe.trident.operation;

import storm.trident.operation.CombinerAggregator;
import storm.trident.tuple.TridentTuple;

import java.math.BigDecimal;

/**
 * Builtin sum works for double, but not for decimal
 */
public class DecimalSum implements CombinerAggregator<BigDecimal> {
    @Override
    public BigDecimal init(TridentTuple tuple) {
        return BigDecimal.valueOf(tuple.getDouble(0));
    }

    @Override
    public BigDecimal combine(BigDecimal val1, BigDecimal val2) {
        return val1.add(val2);
    }

    @Override
    public BigDecimal zero() {
        return BigDecimal.ZERO;
    }
}
