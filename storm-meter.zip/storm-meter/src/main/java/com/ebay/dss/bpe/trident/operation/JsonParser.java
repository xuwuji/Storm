package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.io.IOException;
import java.util.Map;

/**
 * Created by bishao on 1/13/15.
 */
public class JsonParser extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(JsonParser.class);

    private String[] fields;
    private ObjectMapper mapper;

    public JsonParser(String... fieldNames) {
        this.fields = fieldNames;
        mapper = new ObjectMapper();
    }

    public void execute(TridentTuple tuple, TridentCollector collector) {
        String json = tuple.getString(0);
        Map<String, Object> map;
        try {
            map = mapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (IOException e) {
            log.error("Unable to parse json from value {}", json);
            return;
        }
        Values values = new Values();
        for (int i = 0; i < this.fields.length; i++) {
//            if ("itm".equals(this.fields[i]) && map.get(this.fields[i]) != null) {//TODO: improve this hardcode
//                try {//cast to long
//                    values.add(Long.valueOf(map.get(this.fields[i]).toString()));
//                } catch (NumberFormatException nf) {
//                    //itm could be a list!!! 371226497566,371226497566,371226497566,371226497566
//                    values.add(null);
//                }
//            } else {
                values.add(map.get(this.fields[i]));
//            }

        }
        collector.emit(values);
    }
}
