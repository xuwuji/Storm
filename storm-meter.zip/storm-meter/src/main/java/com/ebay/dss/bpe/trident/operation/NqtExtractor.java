package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import com.ebay.dss.bpe.util.Base64Ebay;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.net.URLCodec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.io.UnsupportedEncodingException;
import java.util.BitSet;

/**
 * Created by bishao on 6/4/15.
 */
public class NqtExtractor extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(NqtExtractor.class);

    private static final String EMPTY = "";

    int[] positions;//positions to be extracted

    public NqtExtractor(int... positions) {
        this.positions = positions;
    }

    @Override
    public void execute(TridentTuple tridentTuple, TridentCollector tridentCollector) {
        String nqt = (String)tridentTuple.get(0);
        Values values = new Values();
        BitSet bitSet = parse(nqt);
        StringBuilder sb = new StringBuilder();
        for (int p : positions) {
            if (bitSet.get(p)) {
                if (sb.length() > 0) {
                    sb.append("_");
                }
                sb.append(p);
            }
        }
        values.add(sb.toString());
        tridentCollector.emit(values);
    }

    BitSet parse(String nqt) {
        String escapeEncodedNqt = nqt.replaceAll("%(?![0-9a-fA-F]{2})", "%25");
        String urlDecodedNqt = EMPTY;
        try {
            byte[] bytes = new byte[0];
            bytes = URLCodec.decodeUrl(escapeEncodedNqt.getBytes("UTF-8"));
            urlDecodedNqt = new String(bytes);
        } catch (DecoderException e) {
            log.warn("Unable to decode {}", escapeEncodedNqt);
        } catch (UnsupportedEncodingException e) {
            log.warn("Unable to decode {}", escapeEncodedNqt);
        }
        return getBitSet(urlDecodedNqt);
    }

    private static BitSet getBitSet(String base64EncodedString) {

        if(base64EncodedString == null){
            return new BitSet(0);
        }
        BitSet bitPositions = new BitSet();

        // decode bytes, non standard encoding
        byte[] bytes = Base64Ebay.decode(base64EncodedString, false);
        bitPositions = new BitSet(bytes.length * 8);

        for (int i = 0; i < bytes.length; i++) {
            int b = bytes[i];
            for (int j = 0; j < 8; j++) {
                if ((b & 0x00000080) != 0) {
                    bitPositions.set(i * 8 + j);
                }
                b = b << 1;
            }
        }

        return bitPositions;
    }
}
