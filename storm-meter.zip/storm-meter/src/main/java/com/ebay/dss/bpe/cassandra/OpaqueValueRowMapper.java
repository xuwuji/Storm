package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;
import storm.trident.state.OpaqueValue;

public abstract class OpaqueValueRowMapper<T> extends CompoundKeyRowMapper<OpaqueValue<T>> {
    public OpaqueValueRowMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }

    abstract public OpaqueValue<T> getValue(Row row);
}
