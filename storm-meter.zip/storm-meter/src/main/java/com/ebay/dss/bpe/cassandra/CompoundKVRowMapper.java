package com.ebay.dss.bpe.cassandra;

import com.google.common.base.Preconditions;

public abstract class CompoundKVRowMapper<T extends CompoundValues> extends CompoundKeyRowMapper<CompoundValues> {
    private static final long serialVersionUID = 7738276337117186606L;

    public CompoundKVRowMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }

    @Override
    protected Object[] mapValue(CompoundValues value) {
        Preconditions.checkNotNull(value);
        return value.values.toArray();
    }
}
