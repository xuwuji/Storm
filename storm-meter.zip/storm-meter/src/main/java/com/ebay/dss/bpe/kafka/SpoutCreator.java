package com.ebay.dss.bpe.kafka;

import backtype.storm.spout.SchemeAsMultiScheme;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.StringScheme;
import storm.kafka.ZkHosts;
import storm.kafka.trident.OpaqueTridentKafkaSpout;
import storm.kafka.trident.TridentKafkaConfig;

/**
 * Created by bishao on 4/19/15.
 */
public class SpoutCreator {
    private ZkHosts zkHosts;
    
    public SpoutCreator(String kafkaZk) {
        this.zkHosts = new ZkHosts(kafkaZk, "/brokers");
    }

    public SpoutCreator(String kafkaZk, String zkPath) {
        this.zkHosts = new ZkHosts(kafkaZk, zkPath);
    }

    public OpaqueTridentKafkaSpout createTridentSpout(String topic, String clientId) {
        return createTridentSpout(topic, clientId, false);
    }

    public OpaqueTridentKafkaSpout createTridentSpout(String topic, String clientId, boolean startFromBeginning) {
        TridentKafkaConfig spoutConf = new TridentKafkaConfig(zkHosts, topic, clientId);
        if (!startFromBeginning) {
            spoutConf.startOffsetTime = -1;//start from latest offset
        }
        spoutConf.scheme = new SchemeAsMultiScheme(new StringScheme());
        OpaqueTridentKafkaSpout spout = new OpaqueTridentKafkaSpout(spoutConf);
        return spout;
    }

    public KafkaSpout createSpout(String topic, String clientId) {
        return createSpout(topic, clientId, false);
    }

    public KafkaSpout createSpout(String topic, String clientId, boolean startFromBeginning) {
        SpoutConfig spoutConf = new SpoutConfig(zkHosts, topic, "/kafkastorm", clientId);
        if (!startFromBeginning) {
            spoutConf.startOffsetTime = -1;//start from latest offset
        }
        spoutConf.scheme = new SchemeAsMultiScheme(new StringScheme());
        KafkaSpout spout = new KafkaSpout(spoutConf);
        return spout;
    }
    
}
