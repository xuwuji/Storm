package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import com.ebay.dss.bpe.TransactionFields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Created by bishao on 2/21/15.
 */
public class TransEventParser extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(TransEventParser.class);

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//use HH not hh!!!!
    private final DecimalFormat df = new DecimalFormat("##.00");

    private String[] fields;
    public TransEventParser(String... fieldNames) {
        this.fields = fieldNames;
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String event = (String) tuple.get(0);
        try {
            Values result = new Values();
            Map<String, Object> map = parse(event);
            for (String field : fields) {
                result.add(map.get(field));
            }
            collector.emit(result);
        } catch (Exception e) {
           log.error("Unable to parse transaction event: {}", event, e);
            
        }
    }

    Map<String, Object> parse(String event) {
        Map<String, Object> pairs = new HashMap<String, Object>();
        if (event != null && !"".equals(event.trim())) {
            StringTokenizer st = new StringTokenizer(event, "|");
            while (st.hasMoreElements()) {
                String token = st.nextToken();
                int i = token.indexOf("=");
                if (i < 1) {
                    continue;
                }
                String k = token.substring(0, i);
                String v = token.substring(i + 1);
                //addition parsing
                if (TransactionFields.TIMESTAMP.equals(k)) {
                    try {
                        pairs.put(k, sdf.parse(v).getTime());
                    } catch (ParseException e) {
                        log.error("Unable to parse: createDT=" + v);
                    }
                } else if (TransactionFields.GMV.equals(k)) {
                    try {
                        pairs.put(k, df.parse(v).doubleValue());//parse may return a long if no decimal
                    } catch (ParseException e) {
                        log.error("Unable to gmv: gmv=" + v);
                    }
                } else if (TransactionFields.QUANTITY.equals(k)) {
                    try {
                        pairs.put(k, Integer.valueOf(v));
                    } catch (NumberFormatException e) {
                        log.error("Unable to quantity: quantity=" + v);
                    }
                }//take it as it is...
                else {
                    pairs.put(k, v);
                }

            }
        }
        return pairs;
    }

    public static void main(String[] args) {
        TransEventParser parser = new TransEventParser("gmv", "userId");
        System.out.println(parser.parse("totalAmount=104.99|m_trackingType=3|m_trackingData=prefl%3Den_US%26bs%3D0%26n%3Deb81a3d714b0a5f1426428e4ff9b159c%26bflow%3DFP%26guid%3Deb81a3d714b0a5f1426428e4ff9b159d|itemId=291414755354|userId=1245906024|sellerId=184121227|buyerId=1245906024|m_transactionId=1158456938019|useTransactionId=true|transactionSiteID=0|listingSiteID=100|gmv=104.99|transQuantity=1|transFlags=147474|sellercntry=15|productId=0|categoryOne=107070|categoryTwo=0|quantity=10|createdDT=2015-04-17 09:57:41|transactionType=9|transactionId=1158456938019|lstgStartDt=2015-03-23 23:50:01|lstgEndDt=2015-04-22 23:50:01|lstgTypeCd=9|buyerCntry=1|shpngAmt=0.00|shpngMthdId=1|ckAppId=0|lstgVrtnId=0|expdtdShpngYNInd=N|gmvLstgAmt=104.99|availableQuantity=9|buyerZipcode=04289|itemZipcode=null"));
    }
    
}
