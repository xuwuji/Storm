package com.ebay.dss.bpe.cassandra;

import storm.trident.tuple.TridentTuple;

import java.util.List;

public abstract class CompoundKeyRowMapper<V> extends BaseRowMapper<V> {
    
    public CompoundKeyRowMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }

    @Override
    protected Object[] mapKey(List<Object> key) {
        int n = key.size() - this.keyNames.length;//concat fields from 0 to n 
        if (n == 0) {//downgrade to normal
            return super.mapKey(key);
        }
        Object[] mapped = new Object[this.keyNames.length];
        CompoundKey pk = new StringCompoundKey(key.subList(0, n + 1));
        mapped[0] = pk.get();
        Object[] keys = key.toArray();
        System.arraycopy(keys, n + 1, mapped, 1, key.size() - n - 1);
        return mapped;
    }

    @Override
    protected Object[] mapTuple(TridentTuple tridentTuple) {
        int n = tridentTuple.size() - this.keyNames.length - this.valueNames.length;//concat fields from 0 to n
        if (n == 0) {//downgrade to normal
            return super.mapTuple(tridentTuple);
        }
        Object[] mapped = new Object[this.keyNames.length + this.valueNames.length];
        CompoundKey pk = new StringCompoundKey(tridentTuple.subList(0, n + 1));
        mapped[0] = pk.get();
        Object[] fields = tridentTuple.toArray();
        System.arraycopy(fields, n + 1, mapped, 1, fields.length - n - 1);
        return mapped;
    }

}
