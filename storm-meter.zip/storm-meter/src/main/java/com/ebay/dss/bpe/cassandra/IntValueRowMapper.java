package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;

import java.util.List;

/**
 * Integer value.
 */
@Deprecated
public class IntValueRowMapper extends RowMapper<Integer> {

    /**
     *
     * @param keyspace
     * @param table
     * @param columns
     */
    public IntValueRowMapper(String keyspace, String table, List<String> columns) {
        super(keyspace, table, columns);
    }
    @Override
    public Integer getValue(Row row) {
        return row.getInt(columns[columns.length -1]);
    }

}
