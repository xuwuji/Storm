package com.ebay.dss.bpe.attribution;

import com.ebay.dss.bpe.cassandra.CompoundValues;
import com.google.common.base.Preconditions;

import java.util.List;

/**
 * Created by bishao on 11/4/15.
 */
public class GmvQty extends CompoundValues<GmvQty> {

    public GmvQty(List<Object> values) {
        super(values);
        Preconditions.checkArgument(values.size() == 2);
    }
    
    @Override
    public GmvQty add(GmvQty other) {
        this.values.set(0, (Double)(this.get(0)) + (Double)other.get(0));
        this.values.set(1, (Integer) (this.get(1)) + (Integer) other.get(1));
        return this;
    }
}
