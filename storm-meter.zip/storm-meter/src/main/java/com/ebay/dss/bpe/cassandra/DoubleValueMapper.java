package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;

/**
 * Created by bishao on 11/7/15.
 */
public class DoubleValueMapper extends CompoundKeyRowMapper<Double> {
    /**
     *
     * @param keyspace
     * @param table
     */
    public DoubleValueMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        super(keyspace, table, keyColumns, valueColumns);
    }
    @Override
    public Double getValue(Row row) {
        return row.getDouble(columns[columns.length -1]);
    }

}