package com.ebay.dss.bpe.trident;

import storm.trident.operation.BaseFilter;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 4/20/15.
 */
public class ZipStats extends BaseFilter {
    private int n, i, j, k = 0;
    @Override
    public boolean isKeep(TridentTuple tridentTuple) {
        String buyerZip = tridentTuple.getString(0);
        String itemZip = tridentTuple.getString(1);
        n++;
        if (isValid(buyerZip) && isValid(itemZip)) {
            i++;
        } else if (isValid(buyerZip)) {
            j++;
        } else if (isValid(itemZip)) {
            k++;
        }
        if (n % 10000 == 0) {
            System.out.println("ZipStats total=" + n + " good=" + i + " b=" + j + " s=" + k);
        }
        return false;
    }
    
    private boolean isValid(String zip) {
        return zip != null && !"null".equals(zip) && !"".equals(zip.trim());
    }
}
