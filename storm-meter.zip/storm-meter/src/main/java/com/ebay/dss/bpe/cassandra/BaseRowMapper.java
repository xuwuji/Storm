package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Statement;
import com.datastax.driver.core.querybuilder.Insert;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.google.common.base.Preconditions;
import com.hmsonline.trident.cql.mappers.CqlRowMapper;
import storm.trident.tuple.TridentTuple;

import java.io.Serializable;
import java.util.List;

/**
 * Map K,V into Cassandra Row: grp
 * * *
 */
public abstract class BaseRowMapper<V> implements CqlRowMapper<List<Object>, V>,Serializable {
	private static final long serialVersionUID = 7738276337117186606L;
    protected String keyspace;
    protected String table;
    protected String[] keyNames;
    protected String[] valueNames;
    protected String[] columns;
    protected Object[] columnValues;


    public BaseRowMapper(String keyspace, String table, String[] keyColumns, String[] valueColumns) {
        this.columnValues = new Object[keyColumns.length + valueColumns.length];
        this.table = table;
        this.keyspace = keyspace;
        this.keyNames = keyColumns;
        this.valueNames = valueColumns;
        this.columns = new String[keyColumns.length + valueColumns.length];
        System.arraycopy(keyNames, 0, columns, 0, keyNames.length);
        System.arraycopy(valueNames, 0, columns, keyNames.length, valueNames.length);
    }

    @Override
    public Statement map(List<Object> key, V value) {
        Insert statement = QueryBuilder.insertInto(keyspace, table);
        Object[] mappedKey = mapKey(key);
        Preconditions.checkArgument(mappedKey.length == keyNames.length);

        Object[] mappedValue = mapValue(value);
        Preconditions.checkArgument(mappedValue.length == valueNames.length);
        
        System.arraycopy(mappedKey, 0, columnValues, 0, mappedKey.length);
        System.arraycopy(mappedValue, 0, columnValues, mappedKey.length, mappedValue.length);
        statement.values(columns, columnValues);
        return statement;
    }
    
    protected Object[] mapKey(List<Object> key) {
        return key.toArray();
    }

    protected Object[] mapValue(V value) {
        return new Object[] {value};
        
    }
    protected Object[] mapTuple(TridentTuple tridentTuple) {
        return tridentTuple.toArray();
    }
    
    @Override
    public Statement map(TridentTuple tridentTuple) {
        Insert statement = QueryBuilder.insertInto(keyspace, table);
//        statement.values(columns, tridentTuple.toArray());
//        statement.using(QueryBuilder.ttl(ttl));
        statement.values(columns, mapTuple(tridentTuple));
        return statement;
    }

    @Override
    public Statement retrieve(List<Object> key) {
        Select statement = QueryBuilder.select(columns)
                .from(keyspace, table);
        Object[] mappedKey = mapKey(key);
        for (int i = 0; i < mappedKey.length; i++) {
            statement.where(QueryBuilder.eq(columns[i], mappedKey[i]));
        }
        return statement;
    }
}
