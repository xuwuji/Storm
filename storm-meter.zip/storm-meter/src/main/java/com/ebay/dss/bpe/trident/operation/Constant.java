package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 1/14/15.
 */
public class Constant extends BaseFunction {
    private static final Logger log = LoggerFactory.getLogger(Constant.class);
    private Values constantValue;

    public Constant(Object value) {
        this.constantValue = new Values(value);

    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        collector.emit(constantValue);
    }


}