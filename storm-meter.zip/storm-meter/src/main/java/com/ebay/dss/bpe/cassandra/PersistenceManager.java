package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.Session;
import com.google.common.base.Preconditions;
import com.hmsonline.trident.cql.CassandraCqlMapState;
import com.hmsonline.trident.cql.CassandraCqlMapStateFactory;
import com.hmsonline.trident.cql.mappers.CqlRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import storm.trident.state.StateFactory;
import storm.trident.state.StateType;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by bishao on 4/21/15.
 */
public class PersistenceManager  implements Serializable {
    
    public enum FREQ {
        DEFAULT(""), MINUTE(""), HOUR("hly"), DAY("dly");

        private final String frequency;

        /**
         * @param frequency
         */
        private FREQ(final String frequency) {
            this.frequency = frequency;
        }

        /* (non-Javadoc)
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return frequency;
        }
        
    }
    private static final Logger log = LoggerFactory.getLogger(PersistenceManager.class);
    
    private Map<String, Object> config;
    private String keyspace;
    private CassandraCqlMapState.Options options;
    private Map<String, StateFactory> states;
    
    private transient Session session;
    
    
    public PersistenceManager(Map<String, Object> config) {
        this.config = config;
        this.keyspace = (String)config.get("keyspace");
        options = new CassandraCqlMapState.Options();
        options.keyspace = keyspace;
        Boolean exactlyOnce = config.get("exactlyOnce") != null ? Boolean.valueOf(config.get("exactlyOnce").toString()) : Boolean.FALSE;
        createStates(exactlyOnce);
    }
    
    @Deprecated
    public StateFactory getState(String metrics, boolean detail) {
        if (detail && states.containsKey(metrics + "_dtl")) {
            return states.get(metrics + "_dtl");
        } else if (states.containsKey(metrics)) {
            return states.get(metrics);
        }
        else {
            throw new RuntimeException(metrics + " is not configured.");
        }
    }
    
    public StateFactory getState(String[] metrics, boolean detail,  Class mapperClass) {
        return getState(metrics, detail, mapperClass, FREQ.DEFAULT);
    }

    public StateFactory getState(String[] metrics, boolean detail,  Class mapperClass, FREQ frequency) {
        Preconditions.checkNotNull(metrics);
        String table;
        String[] keys;
        if (detail) {
            table = (String)config.get("table.detail");
            keys = new String[] {"grp1", "ts", "grp2"};
        } else {
            table = (String)config.get("table.summary");
            keys = new String[] {"grp", "ts"};
        }
        
        if (!"".equals(frequency.toString())) {
            table = table + "_" + frequency.toString();
            
        }
        try {
            Constructor constructor = mapperClass.getConstructor(String.class, String.class, String[].class, String[].class);
            CompoundKeyRowMapper mapper = (CompoundKeyRowMapper)constructor.newInstance(keyspace, table, keys, metrics);
            return createState(mapper, StateType.NON_TRANSACTIONAL);
        } catch (Exception e) {
            throw new RuntimeException("Mapper class not found:" + mapperClass.getCanonicalName(), e);
        }
    }
    

    private void createStates(boolean exactlyOnce) {
        List<String> metrics = (List<String>) config.get("metrics.names");
        List<String> types = (List<String>) config.get("metrics.types");
        if (metrics.size() != types.size()) {
            throw new RuntimeException("metrics.names and metrics.types are not configured properly");
        }
        states = new HashMap<String, StateFactory>(metrics.size());
        StateType type = exactlyOnce ? StateType.OPAQUE : StateType.NON_TRANSACTIONAL;
        for (int i = 0; i < metrics.size(); i++) {
            states.put(metrics.get(i), createState(createRowMapper(metrics.get(i), types.get(i), false), type));
            states.put(metrics.get(i) + "_dtl", createState(createRowMapper(metrics.get(i), types.get(i), true), type));
        }

    }

    private StateFactory createState(CqlRowMapper mapper,StateType type) {
        /*Opaque transactional states have the strongest fault-tolerance, but this comes at the cost of needing to store
         the txid and two values in the database. 
         Transactional states require less state in the database, but only work with transactional spouts. Finally, 
         non-transactional states require the least state in the database but cannot achieve exactly-once semantics.
        * * */
        return new CassandraCqlMapStateFactory(
                mapper,
                type,
                options, ConsistencyLevel.ONE);
    }

    private CqlRowMapper createRowMapper(String name, String type, boolean detail) {
        String table;
        String[] keys;
        if (detail) {
            table = (String) config.get("table.detail");
            keys = new String[] {"grp1", "ts", "grp2"};
        } else {
            table = (String) config.get("table.summary");
            keys = new String[] {"grp", "ts"};
        }

        if ("double".equals(type)) {
            return new DoubleValueMapper(keyspace, table, keys, new String[]{name});

        } else {
            return new IntValueMapper(keyspace, table, keys, new String[]{name});
        }
        
    }
    
    public String getFactTable() {
        return (String) config.get("table.fact");
        
    }
    
    public Session getSession() {
        if (session == null) {
            String hosts = (String)config.get("hosts");
            Cluster.Builder builder = Cluster.builder().addContactPoints(hosts.split(","));

            String username = (String)config.get("username");
            String password = (String)config.get("password");
            if (username != null && !"".equals(username)
                    && password != null && !"".equals(password)) {
                builder = builder.withCredentials(username, password);
            }
            Cluster cluster = builder.build();
            this.session = cluster.connect(keyspace);
        }
        return this.session;
        
    }
}
