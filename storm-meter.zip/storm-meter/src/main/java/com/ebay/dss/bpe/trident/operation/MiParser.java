package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import com.google.common.base.Splitter;
import com.google.common.primitives.Ints;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

import java.util.*;

/**
 * Parse mi tag into a Map. The key is module id, value is a list of map, as a module may have multiple entries.
 * The key of the sub map is tracking property id, while the value is the tracking property value.
 * After you get a Map, you can pick * 
 */
public class MiParser extends BaseFunction {
    int[] modules;
    
    /*Specify the interested module id(s)
    * * */
    public MiParser(int... modules) {
        this.modules = modules;
    }
    
    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String mi = (String)tuple.get(0);
        Map<Integer, List<Map<Integer, String>>> map = parse(mi);
        Values value = new Values();
        value.add(map);
        collector.emit(value);
    }

    /*
   * JDK String split
   * For 100000 time run,
   * String.split:2571, Guava.split:3069, StringTokenizer:4794
   * * */
    
public Map<Integer, List<Map<Integer, String>>> parse(String mi) {
        boolean filterModule = this.modules != null && this.modules.length > 0;
        Map<Integer, List<Map<Integer, String>>> result;
        if (filterModule) {
            result = new HashMap<>(this.modules.length);
        } else {
            result = new HashMap<>();
        }

        String[] modules = mi.split(",");

        for(String module : modules) {
            //m(|property:value)+
            String[] split = module.split("\\|");

            String m = split[0];
            int moduleId = Integer.parseInt(m);

            if (filterModule && !Ints.contains(this.modules, moduleId)) {
                continue;
            }
            List<Map<Integer, String>> properites = result.get(moduleId);
            if (properites == null) {
                properites = new ArrayList<>(2);
                result.put(moduleId, properites);
            }
            Map<Integer, String> property = new HashMap<>(3);

            for (int i = 1; i < split.length - 1; i++) {
                String kv = split[i];
                int idx = kv.indexOf(":");
                String k = kv.substring(0, idx);
                String v = kv.substring(idx + 1);
                Integer id = Integer.valueOf(k);
                property.put(id, v);

            }
            properites.add(property);
        }
        return result;
    }

    /*
    * Guava Splitter split
    * * */
    Map<Integer, List<Map<Integer, String>>> parse2(String mi) {
        boolean filterModule = this.modules != null && this.modules.length > 0;
        Map<Integer, List<Map<Integer, String>>> result;
        if (filterModule) {
            result = new HashMap<>(this.modules.length);
        } else {
            result = new HashMap<>();
        }
        
        Iterable<String> modules = Splitter.on(',').split(mi);
        Iterator<String> it = modules.iterator();
        while(it.hasNext()) {
            String module = it.next();//m(|property:value)+
            Iterable<String> mSplit = Splitter.on("|").split(module);
            Iterator<String> mIterator = mSplit.iterator();
            String m = mIterator.next();
            int moduleId = Integer.parseInt(m);

            if (filterModule && !Ints.contains(this.modules, moduleId)) {
                continue;
            }
            List<Map<Integer, String>> properites = result.get(moduleId);
            if (properites == null) {
                properites = new ArrayList<>(2);
                result.put(moduleId, properites);
            }
            Map<Integer, String> property = new HashMap<>(3);
            while (mIterator.hasNext()) {
                String kv = mIterator.next();
                int idx = kv.indexOf(":");
                String k = kv.substring(0, idx);
                String v = kv.substring(idx + 1);
                Integer id = Integer.valueOf(k);
                property.put(id, v);

            }
            properites.add(property);
        }
        return result;
    }


    /*
    * StringTokenizer based split
    * * */
    Map<Integer, List<Map<Integer, String>>> parse3(String mi) {
        boolean filterModule = this.modules != null && this.modules.length > 0;
        Map<Integer, List<Map<Integer, String>>> result;
        if (filterModule) {
            result = new HashMap<>(this.modules.length);
        } else {
            result = new HashMap<>();
        }

        StringTokenizer modules = new StringTokenizer(mi, ",");

        while(modules.hasMoreTokens()) {
            //m(|property:value)+
            String module = modules.nextToken();

            StringTokenizer props = new StringTokenizer(module, "|");

            String m = props.nextToken();
            int moduleId = Integer.parseInt(m);

            if (filterModule && !Ints.contains(this.modules, moduleId)) {
                continue;
            }
            List<Map<Integer, String>> properites = result.get(moduleId);
            if (properites == null) {
                properites = new ArrayList<>(2);
                result.put(moduleId, properites);
            }
            Map<Integer, String> property = new HashMap<>(3);

            while (props.hasMoreTokens()){
                String kv = props.nextToken();
                int idx = kv.indexOf(":");
                String k = kv.substring(0, idx);
                String v = kv.substring(idx + 1);
                Integer id = Integer.valueOf(k);
                property.put(id, v);

            }
            properites.add(property);
        }
        return result;
    }
}
