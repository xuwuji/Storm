package com.ebay.dss.bpe.trident.operation;

import backtype.storm.tuple.Values;
import org.apache.commons.lang.StringUtils;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.tuple.TridentTuple;

/**
 * Created by bishao on 1/16/15.
 */
public class Concat extends BaseFunction {

    private String separator;

    public Concat(String separator) {
        this.separator = separator;
    }
    public void execute(TridentTuple tuple, TridentCollector collector) {
        collector.emit(new Values(StringUtils.join(tuple.iterator(), separator)));
    }
}
