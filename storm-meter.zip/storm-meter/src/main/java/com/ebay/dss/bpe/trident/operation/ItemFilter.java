package com.ebay.dss.bpe.trident.operation;


import com.ebay.dss.bpe.cache.ItemCache;
import storm.trident.operation.BaseFilter;
import storm.trident.operation.TridentOperationContext;
import storm.trident.tuple.TridentTuple;

import java.util.Map;

/**
 */
public class ItemFilter extends BaseFilter {

    private Map<String, Object> cacheConfig;
    private ItemCache cache;

    public ItemFilter(Map<String, Object> cacheConfig) {
        this.cacheConfig = cacheConfig;
    }

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        ItemCache.init(cacheConfig);
        cache = ItemCache.getInstance();
    }

    @Override
    public boolean isKeep(TridentTuple tuple) {
        try {
            Long itemId = Long.valueOf(tuple.get(0).toString());
            return cache.contains(itemId);
        } catch (NumberFormatException nf) {
            //itm could be a list!!! 371226497566,371226497566,371226497566,371226497566
            return false;
        }
    }
}
