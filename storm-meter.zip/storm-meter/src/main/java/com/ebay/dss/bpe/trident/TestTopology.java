package com.ebay.dss.bpe.trident;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.generated.StormTopology;
import backtype.storm.tuple.Fields;
import com.ebay.dss.bpe.BaseTopology;
import com.ebay.dss.bpe.BehaviorFields;
import com.ebay.dss.bpe.kafka.SpoutCreator;
import com.ebay.dss.bpe.trident.operation.DistinctValues;
import com.ebay.dss.bpe.trident.operation.In;
import com.ebay.dss.bpe.trident.operation.JsonParser;
import storm.trident.Stream;
import storm.trident.TridentTopology;

/**
 * Created by bishao on 1/27/15.
 */
public class TestTopology extends BaseTopology {

    public TestTopology(String env) {
        super(env);
    }

    @Override
    public StormTopology build() {
        TridentTopology topology = new TridentTopology();
        SpoutCreator spoutCreator = new SpoutCreator(getConfigString("kafka.zookeeper"));
        Stream stream = topology.newStream(getConfigString("storm.spout.id"),
                spoutCreator.createTridentSpout(getConfigString("kafka.topic.behavioral"), getConfigString("storm.kafka.clientId")));

        String[] names = {BehaviorFields.PAGE, BehaviorFields.SITE, BehaviorFields.TIMESTAMP, BehaviorFields.ITEM, BehaviorFields.REFERER, BehaviorFields.AGENT};
        Fields fields = new Fields(names);
        Stream parsedStream = stream.name("test")
                .each(new Fields("str"), new JsonParser(names), fields)
                .each(new Fields(BehaviorFields.PAGE), new In("284",
                        "4340",
                        "4979",
                        "5408",
                        "5945",
                        "1468719",
                        "1673582",
                        "2041531",
                        "2045314",
                        "2047675",
                        "2047935",
                        "2052027",
                        "2052039",
                        "2054897",
                        "2056116"))
                .each(new Fields(BehaviorFields.ITEM), new In("291518862752"))
                .each(new Fields(BehaviorFields.REFERER), new DistinctValues())
                .each(new Fields(BehaviorFields.AGENT), new DistinctValues());
        return topology.build();
    }

    public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
        String env = "dev";
        if (args != null && args.length >= 2) {
            env = args[0];
        }
        TestTopology topology = new TestTopology(env);
        Config conf = new Config();
        if (args.length == 3) {
            conf.setDebug(Boolean.valueOf(args[2]));
        }
        if ("dev".equals(env)) {
            LocalCluster cluster = new LocalCluster();
            cluster.submitTopology(topology.getName(), conf, topology.build());
        } else {
            conf.setNumWorkers(Integer.valueOf(args[1]));
            StormSubmitter.submitTopology(topology.getName(), conf, topology.build());
        }

    }
}
