package com.ebay.dss.bpe.attribution;

import storm.trident.operation.CombinerAggregator;
import storm.trident.tuple.TridentTuple;

import java.util.ArrayList;
import java.util.Arrays;

/**
 */
public class GmvQtySum implements CombinerAggregator<GmvQty> {


    @Override
    public GmvQty init(TridentTuple tuple) {
        return new GmvQty(tuple.getValues());
    }

    @Override
    public GmvQty combine(GmvQty val1, GmvQty val2) {
        return val1.add(val2);
    }

    @Override
    public GmvQty zero() {
        return new GmvQty(new ArrayList<Object>(Arrays.asList(Double.valueOf(0), Integer.valueOf(0))));
    }
}
