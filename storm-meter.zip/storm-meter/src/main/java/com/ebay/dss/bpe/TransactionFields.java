package com.ebay.dss.bpe;

/**
 * Created by bishao on 2/17/15.
 */
public class TransactionFields {

    public static final String GMV = "gmv";
    public static final String QUANTITY = "transQuantity";
    public static final String ITEM = "itemId";
    public static final String USER = "buyerId";
    public static final String TIMESTAMP = "createdDT";
    public static final String SUM = "sum";

    public static final String BUYER_ZIP = "buyerZipcode";
    public static final String ITEM_ZIP = "itemZipcode";

    public static final String SITE = "transactionSiteID";
    
    public static final String SLR_CNTRY = "sellercntry";
    public static final String BYR_CNTRY = "buyerCntry";
    
    
}
