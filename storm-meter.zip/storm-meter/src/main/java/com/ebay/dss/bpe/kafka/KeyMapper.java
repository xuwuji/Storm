package com.ebay.dss.bpe.kafka;

import org.json.simple.JSONValue;
import storm.kafka.trident.mapper.TridentTupleToKafkaMapper;
import storm.trident.tuple.TridentTuple;

import java.util.HashMap;
import java.util.Map;

/**
 * The key field's value must be string
 */
public class KeyMapper implements TridentTupleToKafkaMapper<Object, String> {
    private String[] names;
    private Map<String, Object> map;
    private String keyName;

    public KeyMapper(String[] names, String keyName) {
        this.names = names;
        map = new HashMap<String, Object>(names.length);
    }

    @Override
    public Object getKeyFromTuple(TridentTuple tuple) {
        try {
            return tuple.getValueByField(keyName);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String getMessageFromTuple(TridentTuple tuple) {
        map.clear();
        for (int i = 0; i < names.length; i++) {
            map.put(names[i], tuple.get(i));

        }
        return JSONValue.toJSONString(map);
    }
}
