package com.ebay.dss.bpe.cassandra;

import org.apache.commons.lang.StringUtils;

import java.util.List;

/**
 * Created by bishao on 11/7/15.
 */
public class StringCompoundKey extends CompoundKey<String> {
    public StringCompoundKey(List<Object> keys) {
        super(keys);
    }

    @Override
    public String get() {
        return StringUtils.join(keys, "_");
    }
}
