package com.ebay.dss.bpe;

/**
 * Created by bishao on 1/13/15.
 */
public class BehaviorFields {
    public final static String GUID = "g";
    public final static String PAGE = "p";
    public final static String USER_COUNTRY = "uc";
    public final static String SITE = "t";

    public final static String ITEM = "itm";

    public final static String USER = "u";
    
    public final static String BEST_USER = "bu";

    public final static String SOURCE = "sid";

    public final static String SOURCE_PAGE = "s_p";

    public final static String SOURCE_MODULE = "s_m";

    public final static String TIMESTAMP = "timestamp";

    public final static String MINUTE = "ts_in_m";

    public final static String COUNT = "count";

    public final static String PGI = "pgi";

    public final static String MI = "mi";
    
    public final static String TRKP = "trkp";
    
    public final static String NQT = "nqt";
    
    public final static String REFERER = "Referer";
    
    public final static String AGENT = "Agent";
    
    
    public final static String CART_ITM = "cart_itm";
    
    

}
