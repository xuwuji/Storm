package com.ebay.dss.bpe.cassandra;

import com.datastax.driver.core.Row;
import com.datastax.driver.core.Statement;
import junit.framework.Assert;
import org.junit.Test;

import java.util.Arrays;

/**
 * Created by bishao on 11/7/15.
 */
public class CompoundKeyRowMapperTest {
    CompoundKeyRowMapper<String> mapper = new CompoundKeyRowMapper<String>(
            "testKeyspace", "testTable",
            new String[] {"_k1", "_k2"}, new String[] {"_v"}) {
        @Override
        public String getValue(Row row) {
            return null;
        }
    };
    
    @Test
    public void testMap() {
        Statement statement = mapper.map(Arrays.<Object>asList("k11", "k12", "k2"), "v1");
        Assert.assertEquals("INSERT INTO testKeyspace.testTable(_k1,_k2,_v) VALUES ('k11_k12','k2','v1');", statement.toString());

        statement = mapper.map(Arrays.<Object>asList("k1", "k2"), "v1");
        Assert.assertEquals("INSERT INTO testKeyspace.testTable(_k1,_k2,_v) VALUES ('k1','k2','v1');", statement.toString());
    }

    @Test
    public void testMap2() {
        MockTridentTuple tuple = new MockTridentTuple(Arrays.asList("_k1", "_k2", "_v"), "k11", "k12", "k2", "v1");
        Statement statement = mapper.map(tuple);
        Assert.assertEquals("INSERT INTO testKeyspace.testTable(_k1,_k2,_v) VALUES ('k11_k12','k2','v1');", statement.toString());

        tuple = new MockTridentTuple(Arrays.asList("_k1", "_k2", "_v"), "k1", "k2", "v1");
        statement = mapper.map(tuple);
        Assert.assertEquals("INSERT INTO testKeyspace.testTable(_k1,_k2,_v) VALUES ('k1','k2','v1');", statement.toString());
    }

    @Test
    public void testRetrieve() {
        Statement statement = mapper.retrieve(Arrays.<Object>asList("k11", "k12", "k2"));
        Assert.assertEquals("SELECT _k1,_k2,_v FROM testKeyspace.testTable WHERE _k1='k11_k12' AND _k2='k2';", statement.toString());

        statement = mapper.retrieve(Arrays.<Object>asList("k1", "k2"));
        Assert.assertEquals("SELECT _k1,_k2,_v FROM testKeyspace.testTable WHERE _k1='k1' AND _k2='k2';", statement.toString());

    }
}
