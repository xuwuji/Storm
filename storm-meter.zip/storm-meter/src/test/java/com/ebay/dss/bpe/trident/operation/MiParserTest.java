package com.ebay.dss.bpe.trident.operation;

import org.junit.Assert;
import org.junit.Test;

import java.util.List;
import java.util.Map;

/**
 * Created by bishao on 9/25/15.
 */
public class MiParserTest {
    private static String mi = "2754|1573:1,2754|1573:1,3966|1573:1,2754|1573:1,123|1573:1,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:1,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:5,3839|1573:1,3839|1573:5,3252|4467:19896%2C19897%2C19983%2C19898%2C19899%2C19900%2C19907%2C19908%2C19909%2C19901%2C19902%2C19903|1573:0,3266|1573:1,3966|1573:1|1573:1,123|1573:1|1573:1,2754|1573:1,3940|3872:1OG97YC2%2C4LZXCXNC%2C3UMCU5I3%2C4UXQ1IRY%2C2KHNPZ6N%2C3GWT2MS5%2C26ZMNNC0%2C4ZQTI6FS%2C48C6MGPV%2C37T6CBQW%2C4QN0UTS4%2C1JUPX6AW%2C4ZNW2EYG%2C4ZEA9G1P%2C48D158CY%2C26UIMWSK%2C547RGRQG%2C48BIYD75%2C4V716OMY|1573:2,3266|3872:3LGGY7WS%2C545YFSX3%2C1JUBH328%2C48BBA62B%2C3Z2RZGU7%2C26ZK87SV%2C3UMAVKFW%2C543T51FB%2C2KI4BXB7%2C487V0AGW%2C4V5CK7S3%2C2KI4BXDS%2C2KI9XRI4%2C48B9Z4XW%2C1T2TDKVV%2C48D222UR%2C2KI1UXLP%2C1OGCOML9%2C1T4I1GHQ%2C1SQK9W71%2C2KJ81VDK%2C48BX9E9N%2C4ZHKJ4SL%2C4V4TIMUY%2C1O54UIRE%2C2KI85Q9E%2C43UN2F85%2C3UGAUHDR%2C4M01OI52%2C2XYF3XAE|1573:3,2735|3872:2KGNB0ZR%2C4QN0USRK%2C1FCKDXCC%2C547R7TH0|5079:5000020111|1573:5,2735|3872:4ZKHUA6L%2C1O93SWHD%2C1FAFSV0L%2C1O2QJ2CX|5079:5000021449|1573:7,3252|1467:19901%2C19902%2C19903|1573:9,2735|3872:1OGBEIFM%2C2YFN9678%2C3ULPJQMI%2C2KJ81VDK|5079:5000021645|1573:10,2735|3872:2TXE51JN%2C3UJD8TP1%2C4M096TAN%2C3UJHU0KJ|5079:5000021439|1573:12,2735|3872:2KHCCKT5%2C4QLWNDKI%2C542RWKXF%2C4M0HY8FC|5079:5000021672|1573:14,2735|3872:43OCNCHH%2C48AEZ70N%2C1T2YTPG8%2C543T51FB|5079:5000021655|1573:16,2735|3872:4UZS72SC%2C26XR4EEM%2C3GWQ6AJ9%2C48BX9E9N|5079:5000021643|1573:18,2735|3872:4HGEEG31%2C4HENGKSW%2C2YENWBV7%2C4H87VB4W|5079:5000021654|1573:20,2735|3872:48CSK5I7%2C1F9L2CCP%2C1JUHK6KF%2C48BP9L85|5079:5000020944|1573:22,2735|3872:21X9GDGH%2C26TCQY2R%2C2YEAKC8L%2C3Z0TYW0K|5079:5000021674|1573:24,2735|3872:4QJZHQ5L%2C37S2EXPR%2C37RCPICP%2C4ZPRS1LU|5079:5000021642|1573:26,2735|3872:37SC00OB%2C2YEVOXG9%2C48CE276G%2C37JQM661|5079:5000021653|1573:28,2735|3872:542PMQQJ%2C3UM5I3S4%2C3GS0NXXN%2C2YFCDCHC|5079:5000021639|1573:30,3839|1670:533b41f517894c828bd3633bUTF-8533b50c2cd770edaa3528627UTF-8533b518f46784c2f79ebaf13|1573:31,2735|3872:1XK034XT%2C1XMAD56T%2C1XPNHSJV%2C1XPTPIF3|5079:5000021656|1573:32,2735|3872:4ZNI595R%2C2TLUJQYX%2C2FQD6K9Q%2C2FMRYAZL|5079:5000021670|1573:34,2735|3872:2G1U9MRM%2C3Z26K6KC%2C2TWSIYPS%2C4LWB45BT|5079:5000021641|1573:36,2735|3872:3UG1UV8W%2C5449A3BS%2C4ZM4ODG5%2C3PT12TH4|5079:5000021671|1573:38,2735|3872:229GE0H2%2C22888IQ7%2C1SXZ5XYT%2C1SZH5Z8I|5079:5000021652|1573:40,2735|3872:3GTM702X%2C3UCUNFIB%2C3UJJ8C16%2C3LG610VL|5079:5000021568|1573:42,2735|3872:4H9CBYEV%2C4ZJDFXLY%2C4ZJ95N6Y%2C2Y76MH7A|5079:5000021545|1573:44,3252|1467:19896%2C19897%2C19983%2C19898%2C19899%2C19900%2C19907%2C19908%2C19909|1573:46,3966|1573:49";


    @Test
    public void testParse() {
        MiParser parser = new MiParser();
        Map<Integer, List<Map<Integer, String>>> map = parser.parse(mi);
        Assert.assertEquals(map.size(), 8);
        Assert.assertEquals(map.get(2754).size(), 4);
        
    }

    @Test
    public void testParseWithFilter() {
        MiParser parser = new MiParser(3839);
        Map<Integer, List<Map<Integer, String>>> map = parser.parse(mi);

        Assert.assertTrue(map.size() == 1);
        Assert.assertEquals(map.get(3839).size(), 21);

    }

    @Test
    public void testPerformance() {
        MiParser parser = new MiParser();
        long start = System.currentTimeMillis();
        for(int i = 0; i < 10000; i++) {
            parser.parse(mi);
//            System.out.println(ids);
//            Assert.assertArrayEquals(ids.toArray(), new Long[]{361276854053L, 301399931610L, 56020130506L});
        }
        long end = System.currentTimeMillis();
        System.out.println("String.split:" + (end - start));

    }

    @Test
    public void testParse2() {
        MiParser parser = new MiParser();
        Map<Integer, List<Map<Integer, String>>> map = parser.parse2(mi);
        Assert.assertEquals(map.size(), 8);
        Assert.assertEquals(map.get(2754).size(), 4);

    }

    @Test
    public void testParseWithFilter2() {
        MiParser parser = new MiParser(3839);
        Map<Integer, List<Map<Integer, String>>> map = parser.parse2(mi);

        Assert.assertTrue(map.size() == 1);
        Assert.assertEquals(map.get(3839).size(), 21);

    }

    @Test
    public void testPerformance2() {
        MiParser parser = new MiParser();
        long start = System.currentTimeMillis();
        for(int i = 0; i < 10000; i++) {
            parser.parse2(mi);
//            System.out.println(ids);
//            Assert.assertArrayEquals(ids.toArray(), new Long[]{361276854053L, 301399931610L, 56020130506L});
        }
        long end = System.currentTimeMillis();
        System.out.println("Guava.split:" + (end - start));

    }

    @Test
    public void testParse3() {
        MiParser parser = new MiParser();
        Map<Integer, List<Map<Integer, String>>> map = parser.parse3(mi);
        Assert.assertEquals(map.size(), 8);
        Assert.assertEquals(map.get(2754).size(), 4);

    }

    @Test
    public void testParseWithFilter3() {
        MiParser parser = new MiParser(3839);
        Map<Integer, List<Map<Integer, String>>> map = parser.parse3(mi);

        Assert.assertTrue(map.size() == 1);
        Assert.assertEquals(map.get(3839).size(), 21);

    }

    @Test
    public void testPerformance3() {
        MiParser parser = new MiParser();
        long start = System.currentTimeMillis();
        for(int i = 0; i < 10000; i++) {
            parser.parse3(mi);
//            System.out.println(ids);
//            Assert.assertArrayEquals(ids.toArray(), new Long[]{361276854053L, 301399931610L, 56020130506L});
        }
        long end = System.currentTimeMillis();
        System.out.println("StringTokenizer:" + (end - start));

    }
    
}
