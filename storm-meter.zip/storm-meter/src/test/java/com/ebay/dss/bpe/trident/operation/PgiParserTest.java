package com.ebay.dss.bpe.trident.operation;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by bishao on 4/21/15.
 */
public class PgiParserTest {
    
    @Test
    public void testParse() {
        PgiParser parser = new PgiParser();
        String[] ids = parser.parse("2051542:0|3205:5515996fe4b02f4e9b82ee7f|1670:552ea18fe4b0e7076a644388");
        Assert.assertArrayEquals(new String[]{"5515996fe4b02f4e9b82ee7f", "552ea18fe4b0e7076a644388"}, ids);
    }
}
