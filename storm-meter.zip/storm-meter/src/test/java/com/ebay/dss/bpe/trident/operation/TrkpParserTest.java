package com.ebay.dss.bpe.trident.operation;

import org.junit.Assert;
import org.junit.Test;

import java.util.Map;

/**
 * Created by bishao on 4/21/15.
 */
public class TrkpParserTest {
    String trkp = "%26rpp_cid%3D55394828e4b01296ae988a8a%26rpp_icid%3D55394741e4b0d23612afd35f";
    
    @Test
    public void testExtract() {
        TrkpParser parser = new TrkpParser("rpp_cid", "rpp_icid", "xxx");
        Map<String, String> extracted = parser.extract("&rpp_cid=550b685ee4b0f9266b7e5ffa&rpp_icid=550b679ce4b03bec964321df");
        Assert.assertEquals("550b685ee4b0f9266b7e5ffa", extracted.get("rpp_cid"));
        Assert.assertEquals("550b679ce4b03bec964321df", extracted.get("rpp_icid"));
        Assert.assertEquals(null, extracted.get("xxx"));
    }
}
