package com.ebay.dss.bpe.trident.operation;

import org.junit.Test;

import java.util.List;

/**
 * Created by bishao on 4/20/15.
 */
public class MiItemExtractorTest {

    private String mi = " mi:2154|1133:228NNKNO,26RJZ6QL,26VDQG72,2262AXGS,1XKJ7ZD1,26S92WRD,1XKJ7ZCE,26VDQFXF,1XK034Y2,26S92WM8,2262AXHY,26VDQFXB,26RJZ6OU,26S92WHJ,1XK03509,2262AXH5,1XK034XT,2262AXGR,1XKYTM3I,225NRDFY,1XN2U5D3,26TF692J,1XN2U59F,226VOF0V,26S92WQB,26VDQG5S,225KLXH6,225KLXIU,26RJZ6MK,26RJZ6NM,225KLXFH,2262AXGF,1XKJ7ZEB,26RJZ6NJ,1XKJ7ZHI,228NNKLG,2262AXG3,225KLXK1,1XKJ7ZFO,26S92WFQ,1XKJ7ZCV,228NNKKG,26VDQG0X,26VDQG24,225KLXFM,228NNKM9,225KLXJA,2262AXGZ,26S92WP1,228NNKKM,26S92WPN,26VDQG7K,1XKJ7ZE9,226RPUM6,1XNIT1EZ,1XK0350U,26RJZ6U0,226RPUS5,26T440CO,26RJZ6PH,26RJZ6NT,,2162|1467:19421,2160,2161,2164,2158,2159,2162,2155,2156,2163";
    
    @Test
    public void testParse() {
        MiItemExtractor parser = new MiItemExtractor();
        long start = System.currentTimeMillis();
        for(int i = 0; i < 10000; i++) {
            List<Long> ids = parser.parse(mi);
//            System.out.println(ids);
//            Assert.assertArrayEquals(ids.toArray(), new Long[]{361276854053L, 301399931610L, 56020130506L});
        }
        long end = System.currentTimeMillis();
        System.out.println(end - start);

    }
}
