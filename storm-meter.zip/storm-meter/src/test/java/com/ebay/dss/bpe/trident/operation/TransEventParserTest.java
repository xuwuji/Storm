package com.ebay.dss.bpe.trident.operation;

import org.junit.Assert;
import org.junit.Test;

import java.util.Map;

/**
 * Created by bishao on 4/19/15.
 */
public class TransEventParserTest {
    
    @Test
    public void testParse() {
        TransEventParser parser = new TransEventParser("gmv", "userId");
        Map<String, Object> values = parser.parse("totalAmount=104.99|m_trackingType=3|m_trackingData=prefl%3Den_US%26bs%3D0%26n%3Deb81a3d714b0a5f1426428e4ff9b159c%26bflow%3DFP%26guid%3Deb81a3d714b0a5f1426428e4ff9b159d|itemId=291414755354|userId=1245906024|sellerId=184121227|buyerId=1245906024|m_transactionId=1158456938019|useTransactionId=true|transactionSiteID=0|listingSiteID=100|gmv=104.99|transQuantity=1|transFlags=147474|sellercntry=15|productId=0|categoryOne=107070|categoryTwo=0|quantity=10|createdDT=2015-04-17 09:57:41|transactionType=9|transactionId=1158456938019|lstgStartDt=2015-03-23 23:50:01|lstgEndDt=2015-04-22 23:50:01|lstgTypeCd=9|buyerCntry=1|shpngAmt=0.00|shpngMthdId=1|ckAppId=0|lstgVrtnId=0|expdtdShpngYNInd=N|gmvLstgAmt=104.99|availableQuantity=9|buyerZipcode=04289|itemZipcode=null");
        Assert.assertEquals(104.99, values.get("gmv"));
        Assert.assertEquals("1245906024", values.get("userId"));
    }
}
