package com.ebay.dss.bpe.trident.operation;

import org.junit.Assert;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by bishao on 12/18/15.
 */
public class RoundTimestampTest {
    @Test
    public void testRoundToDay() {
        RoundTimestamp rt = new RoundTimestamp(Calendar.DATE);
        long timestamp = 1450426866413L;
        Date date = rt.round(timestamp);//1450396800000
        Assert.assertEquals(1450422000000L, date.getTime());//1450396800000

    }

    @Test
    public void testRoundToHour() {
        RoundTimestamp rt = new RoundTimestamp(Calendar.HOUR);
        long timestamp = 1450426866413L;
        Date date = rt.round(timestamp);
        Assert.assertEquals(1450425600000L, date.getTime());

    }

    @Test
    public void testRoundToMinute() {
        RoundTimestamp rt = new RoundTimestamp(Calendar.MINUTE);
        long timestamp = 1450426866413L;
        Date date = rt.round(timestamp);
        Assert.assertEquals(1450426860000L, date.getTime());

    }

    @Test
    public void testRoundToSecond() {
        RoundTimestamp rt = new RoundTimestamp(Calendar.SECOND);
        long timestamp = 1450426866413L;
        Date date = rt.round(timestamp);
        Assert.assertEquals(1450426866000L, date.getTime());

    }
}
