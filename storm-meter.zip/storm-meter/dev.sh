ZK_HOME=/Applications/apache/zookeeper-3.4.6
CASSANDRA_HOME=/Applications/apache/apache-cassandra-2.0.13
KAFKA_HOME=/Applications/apache/kafka_2.11-0.8.2.1


$ZK_HOME/bin/zkServer.sh start

$CASSANDRA_HOME/bin/cassandra

$KAFKA_HOME/bin/kafka-server-start.sh $KAFKA_HOME/config/server.properties &



mongod &




