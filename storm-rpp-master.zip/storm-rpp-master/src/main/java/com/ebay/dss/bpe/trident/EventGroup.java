package com.ebay.dss.bpe.trident;


import backtype.storm.tuple.Values;
import com.ebay.dss.bpe.EventCache;
import storm.trident.operation.BaseFunction;
import storm.trident.operation.TridentCollector;
import storm.trident.operation.TridentOperationContext;
import storm.trident.tuple.TridentTuple;

import java.util.Map;

/**
 * Created by bishao on 8/14/15.
 */
public class EventGroup extends BaseFunction {

    private Map<String, Object> cacheConfig;
    private EventCache cache;
    
    public EventGroup(Map<String, Object> cacheConfig) {
        this.cacheConfig = cacheConfig;
    }

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        EventCache.init(cacheConfig);
        cache = EventCache.getInstance();
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {
        String event = (String) tuple.get(0);
        Values value = new Values();
        value.add(cache.getGroup(event));
        collector.emit(value);
    }
}
