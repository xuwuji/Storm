package com.ebay.dss.bpe;

import com.mongodb.*;
import gnu.trove.set.hash.THashSet;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by bishao on 8/14/15.
 */
public class EventCache extends Timer {
    private static final Logger log = LoggerFactory.getLogger(EventCache.class);

    private static EventCache instance;

    private Map<String, Object> config;
    private Map<String, String> eventGroups;


    private EventCache(Map<String, Object> config) {
        this.config = config;
        eventGroups = new HashMap<String, String>(6000);
    }
    public static void init(Map<String, Object> config) {
        if(instance == null) {
            synchronized(EventCache.class) {
                if(instance == null) {
                    log.info("Initializing Item Cache...");
                    instance = new EventCache(config);
                    instance.refresh();
                    RefreshTask task = new RefreshTask();
                    long interval = Long.valueOf((Integer) config.get("refreshMilliseconds"));//ymal recognize as int...
                    instance.scheduleAtFixedRate(task, interval, interval);
                }
            }
        }
    }

    public static EventCache getInstance() {
        if (instance == null) {
            throw new RuntimeException("Call ItemCache.init() first.");
        }
        return instance;
    }

    public String getGroup(String event) {
        String group = eventGroups.get(event);
        if (group == null) {
            log.warn("Unable to get group for: {}", event);
        }
        return group;
    }

    private void refresh() {
        Mongo mongo = null;
        try {
            log.info("Refreshing Event Cache, initial size {}", eventGroups.size());
            List<String> hosts = (List<String>)config.get("mongoHosts");
            List<ServerAddress> servers = new ArrayList<ServerAddress>(hosts.size());
            for (int i = 0; i < hosts.size(); i++) {
                String[] hostStr = hosts.get(i).split(":");
                servers.add(new ServerAddress(hostStr[0], Integer.valueOf(hostStr[1])));
            }
            mongo = new MongoClient(servers);

            DBCollection collection = mongo.getDB((String)config.get("mongoDB")).
                    getCollection((String) config.get("mongoCollection"));
            BasicDBObject keys = new BasicDBObject();
            keys.put("_id", 1);
            keys.put("group", 1);
            Date date = DateUtils.addHours(new Date(), -1 * (Integer) config.get("livehour"));
            //db.events.find({"endDate": {$gt: "1451251800000"}})
            BasicDBObject query = new BasicDBObject("endDate", new BasicDBObject("$gte", String.valueOf(date.getTime())));
            log.info("Refreshing Event Cache with: " + query.toString());
            DBCursor cursor = collection.find(query, keys);
            Set<String> newSet = new THashSet<String>((Integer)config.get("initialCapacity"),
                    ((Double)config.get("loadFactor")).floatValue());
            while (cursor.hasNext()) {
                DBObject object = cursor.next();
                String id = (String) object.get("_id");
                String group = (String) object.get("group");
                newSet.add(id);
                eventGroups.put(id, group);
            }
            if (newSet.size() > 0) {
                Iterator<String> iterator = eventGroups.keySet().iterator();
                while (iterator.hasNext()) {
                    String key = iterator.next();
                    if (!newSet.contains(key)) {
                        iterator.remove();
                    }
                }
            }
            log.info("After refresh, event Cache size {}", eventGroups.size());
        } catch (Exception e) {
            log.error("Unable to get events from MongoDB:", e);
        } finally {
            if (mongo != null) {
                mongo.close();
            }
        }

    }

    private static class RefreshTask extends TimerTask {
        @Override
        public void run() {
            EventCache.getInstance().refresh();
        }
    }

    public static void main(String[] args) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put("mongoHosts", Arrays.asList("localhost:27017"));
        config.put("mongoDB", "rpp");
        config.put("mongoCollection", "events");
        config.put("refreshMilliseconds", 60000);
        config.put("initialCapacity", 10000);
        config.put("loadFactor", 1.0);
        config.put("livehour", 48);
        EventCache.init(config);
        EventCache cache = EventCache.getInstance();
        System.out.println(cache.getGroup("5551193ee4b08d4041a2c224"));

    }

}