Dependencies:
    
    https://github.corp.ebay.com/BIS/storm-meter
    https://github.corp.ebay.com/bishao/storm-cassandra-cql

Local developement requires:
    
    zookeeper-3.4.6
    apache-cassandra-2.0.13
    kafka_2.11-0.8.2.1
    mongodb

1. Input:
        
        a. Transaction stream from Kafka
        b. Behavior stream from Kafka
        c. RPP live events/event groups and item set from MongoDB

2. Output: 
        
        a. aggregated numbers in Cassandra
        b. impression sub-stream to Kafka

3. Using Cassandra for simple attribution, join Transaction and VI 

