import time
import requests
import json

from sets import Set
from pymongo import MongoClient
from datetime import datetime
import sys


env = sys.argv[1]
print env

if env == 'prod':
    mongohost = "slcdbx1053-6.slc.ebay.com:27017,lvsdbx1003-6.lvs.ebay.com:27017,phxdbx1047-6.phx.ebay.com:27017/?replicaSet=CuratedTrendRS"
    url = 'http://www.rps.stratus.ebay.com/rps'
elif env == 'qa':
    mongohost = "sm-curatedtrend1.db.stratus.qa.ebay.com:27017,sm-curatedtrend2.db.stratus.qa.ebay.com:27017,sm-curatedtrend3.db.stratus.qa.ebay.com:27017"
    url = 'http://www.qa.ebay.com/rps'
else:
    mongohost = "localhost:27017"
    url = 'http://www.qa.ebay.com/rps'
    #url = 'http://www.rps.stratus.ebay.com/rps'

print mongohost
print url

start = int(round(time.time() * 1000))
end = start + 86400000

events_url = url + '/events?&active=true&fetchSize=5000&pageNo=1&startsBefore='+ str(start) +'&endsAfter='+ str(end)
print events_url
events_response = requests.get(events_url)

print 'total active events: ' + str(events_response.json()['totalCount'])
events = events_response.json()['events']

item_url = url + '/finditems'
client = MongoClient("mongodb://" + mongohost)
db = client['rpp']
item_collection = db['items']
eventgrp_collection = db['eventgroups']
events_collection=db['events']

event_set = Set()
eventgroup_set = Set()
item_set = Set()

item_count = 0
headers = {'Content-type': 'application/json'}
for event in events:
    try:
        groupId = event['group']
        if groupId not in eventgroup_set:
             event_group_url = url + '/eventgroups/' + groupId
             # print event_group_url
             event_group = requests.get(event_group_url).json()
             event_group['_id'] = event_group.pop('id')
             eventgrp_collection.save(event_group)
             eventgroup_set.add(groupId)
    
        data = {"siteId": event['siteId'], "eventId": event['id'], "paginationInput":{ "entriesPerPage":1000000, "pageNumber":1}}
        data_json = json.dumps(data)
        # print data_json
        response = requests.post(item_url, data=data_json, headers=headers)
        # print response.json()
        result = response.json()

        n = int(result.get('matchCount', '0'))
        if n > 0:
            items = result.get('searchRecord', [])
            item_count = item_count + n
            for item in items:
                itm = item['item']
                itm['_id'] = itm.pop('itemId')
                itm['fetch_time'] = datetime.now()
                item_collection.save(itm)
                item_set.add(itm['_id'])
    
        event['_id'] = event.pop('id')
        events_collection.save(event)
        event_set.add(event['_id'])
    except KeyError as e:
        print event
        
print 'total items imported from active events:' + str(item_count)
print len(event_set)
print len(eventgroup_set)
print len(item_set)

