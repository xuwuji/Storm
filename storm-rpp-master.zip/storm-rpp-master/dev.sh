ZK_HOME=/Applications/apache/zookeeper-3.4.6
CASSANDRA_HOME=/Applications/apache/apache-cassandra-2.0.13
KAFKA_HOME=/Applications/apache/kafka_2.11-0.8.2.1
MONGO_HOME=/Applications/mongodb-osx-x86_64-3.0.1


$ZK_HOME/bin/zkServer.sh start

$CASSANDRA_HOME/bin/cassandra

$KAFKA_HOME/bin/kafka-server-start.sh $KAFKA_HOME/config/server.properties &



$MONGO_HOME/bin/mongod &



cd $KAFKA_HOME/bin/
./kafka-topics.sh --zookeeper localhost:2181 --create --topic behavioral.event  --replication-factor 1 --partitions 1
./kafka-topics.sh --zookeeper localhost:2181 --create --topic transaction.new  --replication-factor 1 --partitions 1
./kafka-topics.sh --zookeeper localhost:2181 --create --topic bpe.rpp  --replication-factor 1 --partitions 1
