## 0.2.4

* Bump cassandra-driver-core dependency to 2.1.4

## 0.2.1

* [#27][]: Use QUORUM by default instead of LOCAL_QUORUM

## 0.2.0

* [#22][] / [#26][]: Explicit consistency levels for batches, cluster, and conditional updates

[#22]: https://github.com/hmsonline/storm-cassandra-cql/issues/22
[#26]: https://github.com/hmsonline/storm-cassandra-cql/issues/26
[#27]: https://github.com/hmsonline/storm-cassandra-cql/issues/27
